<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

  class MainPage extends CI_Controller
  {
    public function __construct()
    {
      parent::__construct();
      $this->load->helper('url');
      $this->load->library('session');
    }
    public function index()
    {
      $this->cek_aktif();
      $this->load->view('MainPage_view');
    }

    public function cek_aktif()
    {
      if ($this->session->userdata('admin_id') == '') {
        redirect('MainPage/login');
      }
    }

    public function login()
    {
      $this->load->view('Login_view');
    }

    public function logout()
    {
      $data = array(
        'admin_id' => '',
        'admin_user' => '',
        'admin_level' => '',
        'admin_nama' => '',
        'admin_add' => '',
        'admin_edit' => '',
        'admin_delete' => '',
        'admin_valid' => false
      );

      $this->session->set_userdata($data);
      redirect('MainPage');
  }
}
?>
