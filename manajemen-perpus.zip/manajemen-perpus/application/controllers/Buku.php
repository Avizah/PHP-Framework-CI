<?php if (!defined('BASEPATH')) exit('No direct script access alloed');

  class Buku extends CI_Controller
  {
    public function __construct()
    {
      parent::__construct();
      $this->load->helper('url');
      $this->load->model('Buku_model');
    }

    public function index()
    {
      $data['daftarPenulis'] = $this->Buku_model->getData('tb_penulis', 'kd_penulis', 'nama');
      $data['daftarPenerbit'] = $this->Buku_model->getData('tb_penerbit', 'kd_penerbit', 'nama');
      $data['daftarGenre'] = $this->Buku_model->getData('tb_genre', 'kd_genre', 'nama_genre');
      $this->load->view('Buku_view', $data);
    }

    public function getSubGenre($idGenre)
    {
      $result = $this->Buku_model->getData('tb_subgenre', 'kd_subgenre', 'nama_subgenre', 'kd_genre', $idGenre);

      $data = array();
      $i = 0;
      foreach ($result as $r) {
        $data[$i]['value'] = $r['kd_subgenre'];
        $data[$i]['text'] = $r['nama_subgenre'];
        $i++;
      }

      echo json_encode($data);
    }

    public function add()
    {
      if(!isset ($_POST))
  			show_404();

  		if($this->Buku_model->add())
  			echo json_encode(array('success'=>true));
  		else
  			echo json_encode(array('msg'=>'Gagal Memasukkan Data'));
    }

    public function edit($txtId = null)
  	{
  		if(!isset($_POST))
  			show_404();

  		if($this->Buku_model->edit($txtId))
  			echo json_encode(array('success'=>true));
  		else
  			echo json_encode(array('msg'=>'Gagal Mengubah Data'));
  	}

  	public function delete()
  	{
  		if(!isset($_POST))
  			show_404();

  		$id = intval(addslashes($_POST['id']));
  		if($this->Buku_model->delete($id))
  			echo json_encode(array('success'=>true));
  		else
  			echo json_encode(array('msg'=>'Gagal menghapus data'));
  	}

    public function getJson()
  	{
  		$offset = isset($_POST['page']) ? intval($_POST['page']) : 1;
  		$limit = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
  		$field = isset($_POST['findId']) ? $_POST['findId'] : '';
  		$search = isset($_POST['findNilai']) ? $_POST['findNilai'] : '';
  		$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'kd_buku';
  		$order = isset($_POST['order']) ? strval($_POST['order']) : 'asc';

  		$offset = ($offset-1)*$limit;
  		$criteria = $this->Buku_model->getJson($offset, $limit, $field, $search, $sort, $order);
  		$i = 0;
  		$rows = array();
  		foreach ($criteria ['data'] as $r)
  		{
  			$rows[$i]['txtId'] = $r->kd_buku;
        $rows[$i]['cmbPenulis'] = $r->kd_penulis;
        $rows[$i]['cmbPenerbit'] = $r->kd_penerbit;
        $rows[$i]['cmbGenre'] = $r->kd_genre;
        $rows[$i]['cmbSubGenre'] = $r->kd_subgenre;
  			$rows[$i]['txtIsbn'] = $r->isbn;
        $rows[$i]['txtJudulBuku'] = $r->judul;
        $rows[$i]['txtEdisi'] = $r->edisi;
        $rows[$i]['txtNamaPenulis'] = $r->nama_penulis;
        $rows[$i]['txtNamaPenerbit'] = $r->nama_penerbit;
        $rows[$i]['txtThnTerbit'] = $r->tahun_terbit;
        $rows[$i]['txtNamaGenre'] = $r->nama_genre;
        $rows[$i]['txtNamaSubGenre'] = $r->nama_subgenre;
        $rows[$i]['txtStok'] = $r->jml_stok;
  			$i++;
  		}
  		$result = array('total'=>$criteria['count'],'rows'=>$rows);
  		echo json_encode($result);
  	}
  }

?>
