<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

  class SubGenre extends CI_Controller
  {
    public function __construct()
    {
      parent::__construct();
      $this->load->helper('url');
      $this->load->model('SubGenre_model');
    }

    public function index()
    {
      $data['genre']=$this->SubGenre_model->getGenre();
      $this->load->view('SubGenre_view', $data);
    }

    public function add()
  	{
  		if(!isset ($_POST))
  			show_404();

  		if($this->SubGenre_model->add())
  			echo json_encode(array('success'=>true));
  		else
  			echo json_encode(array('msg'=>'Gagal Memasukkan Data'));
  	}

  	public function edit($txtId=null)
  	{
  		if(!isset($_POST))
  			show_404();

  		if($this->SubGenre_model->edit($txtId))
  			echo json_encode(array('success'=>true));
  		else
  			echo json_encode(array('msg'=>'Gagal Mengubah Data'));
  	}

  	public function delete()
  	{
  		if(!isset($_POST))
  			show_404();

  		$id = intval(addslashes($_POST['id']));
  		if($this->SubGenre_model->delete($id))
  			echo json_encode(array('success'=>true));
  		else
  			echo json_encode(array('msg'=>'Gagal menghapus data'));
  	}

    public function getJson()
  	{
  		$offset = isset($_POST['page']) ? intval($_POST['page']) : 1;
  		$limit = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
  		$field = isset($_POST['findId']) ? $_POST['findId'] : '';
  		$search = isset($_POST['findNilai']) ? $_POST['findNilai'] : '';
  		$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'kd_subgenre';
  		$order = isset($_POST['order']) ? strval($_POST['order']) : 'asc';

  		$offset = ($offset-1)*$limit;
  		$criteria = $this->SubGenre_model->getJson($offset, $limit, $field, $search, $sort, $order);
  		$i = 0;
  		$rows = array();
  		foreach ($criteria ['data'] as $r)
  		{
  			$rows[$i]['txtId'] = $r->kd_subgenre;
        $rows[$i]['txtIdGenre'] = $r->kd_genre;
  			$rows[$i]['txtNamaSubGenre'] = $r->nama_subgenre;
        $rows[$i]['txtNamaGenre'] = $r->nama_genre;
  			$i++;
  		}
  		$result = array('total'=>$criteria['count'],'rows'=>$rows, 'sql'=>$criteria['sql']);
  		echo json_encode($result);
  	}
  }

?>
