<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

  class Genre extends CI_Controller
  {
    public function __construct()
    {
      parent::__construct();
      $this->load->helper('url');
      $this->load->model('Genre_model');
    }

    public function index()
    {
      $this->load->view('Genre_view');
    }

    public function add()
    {
      if(!isset($_POST))
        show_404();

      if($this->Genre_model->add())
        echo json_encode(array('success'=>true));
      else
        echo json_encode(array('msg'=>'Gagal memasukkan data'));
    }

    public function edit($txtId=null)
    {
      if(!isset($_POST))
        show_404();

      if($this->Genre_model->edit($txtId))
        echo json_encode(array('success'=>true));
      else
        echo json_encode(array('msg'=>'Gagal mengubah data'));
    }

    public function delete()
    {
      if(!isset($_POST))
      show_404();

      $id = intval (addslashes($_POST['id']));
      if($this->Genre_model->delete($id))
      echo json_encode(array('success'=>true));
      else {
        echo json_encode(array('msg'=>'Gagal menghapus data'));
      }
    }


    public function getJson(){
      $offset = isset($_POST['page']) ? intval($_POST['page']) : 1;
      $limit = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
      $field = isset($_POST['findId']) ? $_POST['findId'] : '';
      $search = isset($_POST['findNilai']) ? $_POST['findNilai'] : '';
      $sort = isset($_POST['sort']) ? $_POST['sort'] : 'kd_genre';
      $order = isset($_POST['order']) ? strval($_POST['order']) : 'asc';

      $offset = ($offset-1)*$limit;
      $criteria = $this->Genre_model->getJson($offset,$limit,$field,$search,$sort,$order);
      $i = 0;
      $rows = array();
      foreach ($criteria ['data'] as $r) {
        $rows[$i]['txtId'] = $r->kd_genre;
        $rows[$i]['txtNamaGenre'] = $r->nama_genre;

      $i++;
      }
      $result = array('total'=>$criteria['count'],'rows'=>$rows);
      echo json_encode($result);
    }

  }

?>
