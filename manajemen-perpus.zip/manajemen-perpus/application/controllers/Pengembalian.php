<?php if (!defined('BASEPATH')) exit('No direct script access alloed');

  class Pengembalian extends CI_Controller
  {
    public function __construct()
    {
      parent::__construct();
      $this->load->helper('url');
      $this->load->model('Pengembalian_model');
    }

    public function index()
    {
      $data['daftarPengembali'] = $this->Pengembalian_model->getData('tb_member', 'id_member', 'nama');
      $data['daftarStaf'] = $this->Pengembalian_model->getData('tb_staf', 'id_staf', 'nama');
      $this->load->view('Pengembalian_view', $data);
    }

    public function add()
    {
      if(!isset ($_POST))
  			show_404();

      if($this->Pengembalian_model->add())
  			echo json_encode(array('success'=>true));
  		else
  			echo json_encode(array('msg'=>'Gagal Memasukkan Data'));
    }

    public function delete()
  	{
  		if(!isset($_POST))
  			show_404();

  		$id = intval(addslashes($_POST['id']));
  		if($this->Pengembalian_model->delete($id))
  			echo json_encode(array('success'=>true));
  		else
  			echo json_encode(array('msg'=>'Gagal menghapus data'));
  	}

    public function getBook()
    {
      if(!isset ($_POST))
        show_404();

      $bookData = $this->Pengembalian_model->getBook();
      if($bookData)
      {
        $data = array();
        $data['txtIdPeminjaman'] = $bookData->kd_transaksi;
        $data['txtBookId'] = $bookData->kd_buku;
        $data['txtJudulBuku'] = $bookData->judul;
        $data['txtTglJatuhTempo'] = $bookData->tgl_jth_tempo;
        $data['success'] = true;

        echo json_encode($data);
      }
      else
        echo json_encode(array('success' => false, 'msg'=>'Gagal Mencari Data Buku'));
    }

    public function getBooklist($kd_transaksi)
    {
      $offset = isset($_POST['page']) ? intval($_POST['page']) : 1;
  		$limit = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
  		$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'kd_buku';
  		$order = isset($_POST['order']) ? strval($_POST['order']) : 'asc';

  		$offset = ($offset-1)*$limit;
  		$criteria = $this->Pengembalian_model->getBooklist($offset, $limit, $sort, $order, $kd_transaksi);
  		$i = 0;
  		$rows = array();
  		foreach ($criteria ['data'] as $r)
  		{
        $rows[$i]['txtIdPeminjaman'] = $r->kd_peminjaman;
        $rows[$i]['txtBookId'] = $r->kd_buku;
        $rows[$i]['txtJudulBuku'] = $r->judul;
        $rows[$i]['txtTglJatuhTempo'] = $r->tgl_jth_tempo;

  			$i++;
  		}
  		$result = array('total'=>$criteria['count'],'rows'=>$rows);
  		echo json_encode($result);
    }

    public function getJson()
    {
      $offset = isset($_POST['page']) ? intval($_POST['page']) : 1;
  		$limit = isset($_POST['rows']) ? intval($_POST['rows']) : 10;
  		$field = isset($_POST['findId']) ? $_POST['findId'] : '';
  		$search = isset($_POST['findNilai']) ? $_POST['findNilai'] : '';
  		$sort = isset($_POST['sort']) ? strval($_POST['sort']) : 'kd_transaksi';
  		$order = isset($_POST['order']) ? strval($_POST['order']) : 'asc';

  		$offset = ($offset-1)*$limit;
  		$criteria = $this->Pengembalian_model->getJson($offset, $limit, $field, $search, $sort, $order);
  		$i = 0;
  		$rows = array();
  		foreach ($criteria ['data'] as $r)
  		{
  			$rows[$i]['txtId'] = $r->kd_transaksi;
        $rows[$i]['cmbMember'] = $r->kd_member;
        $rows[$i]['cmbStaf'] = $r->kd_staf;
        $rows[$i]['txtTglPengembalian'] = $r->tgl_pengembalian;
        $rows[$i]['txtNamaMember'] = $r->nama_member;
        $rows[$i]['txtNamaStaf'] = $r->nama_staf;

  			$i++;
  		}
  		$result = array('total'=>$criteria['count'],'rows'=>$rows);
  		echo json_encode($result);
    }

    public function export()
    {
      $filetype = $this->input->post('cmbFileType', true);
      $reportData = $this->Pengembalian_model->getReportData();

      if ($filetype == 'pdf') {
        $this->pdfBuilder($reportData);
      } else if ($filetype == 'excel') {
        $this->excelBuilder($reportData);
      }
    }

    public function pdfBuilder($reportData)
    {
      include APPPATH.'third_party/fpdf181/fpdf.php';

      $pdf = new FPDF('L', 'mm', 'Legal');
      $pdf->AddPage();

      $pdf->SetFont('Arial', 'B', 16);
      $pdf->Cell(356, 7, 'Laporan Transaksi Pengembalian Buku', 0, 1, 'C');

      $pdf->SetFont('Arial', 'B', 12);
      $pdf->Cell(356, 7, 'Pustaka Indo', 0, 1, 'C');

      $pdf->Cell(10, 7, '', 0, 1);

      $pdf->SetFont('Arial', 'B', 10);
      $pdf->Cell(12, 6, 'NO', 1, 0, 'C');
      $pdf->Cell(30, 6, 'KD TRANSAKSI', 1, 0, 'C');
      $pdf->Cell(40, 6, 'TGL PENGEMBALIAN', 1, 0, 'C');
      $pdf->Cell(37, 6, 'TGL JATUH TEMPO', 1, 0, 'C');
      $pdf->Cell(55, 6, 'JUDUL BUKU', 1, 0, 'C');
      $pdf->Cell(55, 6, 'NAMA STAF', 1, 0, 'C');
      $pdf->Cell(55, 6, 'NAMA PEMINJAM', 1, 0, 'C');
      $pdf->Cell(50, 6, 'KETERANGAN', 1, 0, 'C');

      $pdf->SetFont('Arial', '', 10);
      $no = 1;
      foreach ($reportData as $data) {
        $dateDiff = strtotime($data->tgl_jth_tempo) - strtotime($data->tgl_pengembalian);
        $status = ($dateDiff > 0) ? 'Tepat Waktu' : 'Terlambat';

        $pdf->Cell(10, 6, '', 0, 1);
        $pdf->Cell(12, 6, $no, 1, 0);
        $pdf->Cell(30, 6, $data->kd_transaksi, 1, 0);
        $pdf->Cell(40, 6, $data->tgl_pengembalian, 1, 0);
        $pdf->Cell(37, 6, $data->tgl_jth_tempo, 1, 0);
        $pdf->Cell(55, 6, $data->judul, 1, 0);
        $pdf->Cell(55, 6, $data->nama_staf, 1, 0);
        $pdf->Cell(55, 6, $data->nama_member, 1, 0);
        $pdf->Cell(50, 6, $status, 1, 0);

        $no++;
      }

      $pdf->Output('D', 'Laporan Pengembalian Buku.pdf');
    }

    public function excelBuilder($reportData)
    {
      include APPPATH.'third_party/PHPExcel/PHPExcel.php';

      $excel = new PHPExcel;

      $excel->getProperties()->setCreator('Imam Nududdin')
          ->setLastModifiedBy('Imam Nududdin')
          ->setTitle('Pengembalian Buku')
          ->setSubject('Pengembalian Buku')
          ->setDescription('Laporan Transaksi Pengembalian Buku')
          ->setKeywords('Pengembalian Buku');

      $style_col = array(
        'font' => array('bold' => true),
        'alignment' => array(
          'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
          'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),
        'borders' => array(
          'top' => array('style' => PHPExcel_Style_Border::BORDER_THIN),
          'right' => array('style' => PHPExcel_Style_Border::BORDER_THIN),
          'bottom' => array('style' => PHPExcel_Style_Border::BORDER_THIN),
          'left' => array('style' => PHPExcel_Style_Border::BORDER_THIN)
        )
      );

      $style_row = array(
        'alignment' => array(
          'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
        ),
        'borders' => array(
          'top' => array('style' => PHPExcel_Style_Border::BORDER_THIN),
          'right' => array('style' => PHPExcel_Style_Border::BORDER_THIN),
          'bottom' => array('style' => PHPExcel_Style_Border::BORDER_THIN),
          'left' => array('style' => PHPExcel_Style_Border::BORDER_THIN)
        )
      );

      $excel->setActiveSheetIndex(0)->setCellValue('A1', 'DATA LAPORAN TRANSAKSI PENGEMBALIAN BUKU');
      $excel->getActiveSheet()->mergeCells('A1:H1');
      $excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE);
      $excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(15);
      $excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

      $excel->setActiveSheetIndex(0)->setCellValue('A3', 'NO');
      $excel->setActiveSheetIndex(0)->setCellValue('B3', 'KD TRANSAKSI');
      $excel->setActiveSheetIndex(0)->setCellValue('C3', 'TGL PENGEMBALIAN');
      $excel->setActiveSheetIndex(0)->setCellValue('D3', 'TGL JATUH TEMPO');
      $excel->setActiveSheetIndex(0)->setCellValue('E3', 'JUDUL BUKU');
      $excel->setActiveSheetIndex(0)->setCellValue('F3', 'NAMA STAF');
      $excel->setActiveSheetIndex(0)->setCellValue('G3', 'NAMA PEMINJAM');
      $excel->setActiveSheetIndex(0)->setCellValue('H3', 'KETERANGAN');

      $excel->getActiveSheet()->getStyle('A3')->applyFromArray($style_col);
      $excel->getActiveSheet()->getStyle('B3')->applyFromArray($style_col);
      $excel->getActiveSheet()->getStyle('C3')->applyFromArray($style_col);
      $excel->getActiveSheet()->getStyle('D3')->applyFromArray($style_col);
      $excel->getActiveSheet()->getStyle('E3')->applyFromArray($style_col);
      $excel->getActiveSheet()->getStyle('F3')->applyFromArray($style_col);
      $excel->getActiveSheet()->getStyle('G3')->applyFromArray($style_col);
      $excel->getActiveSheet()->getStyle('H3')->applyFromArray($style_col);

      $no = 1;
      $numrow = 4;

      foreach ($reportData as $data) {
        $dateDiff = strtotime($data->tgl_jth_tempo) - strtotime($data->tgl_pengembalian);
        $status = ($dateDiff > 0) ? 'Tepat Waktu' : 'Terlambat';

        $excel->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $no);
        $excel->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $data->kd_transaksi);
        $excel->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $data->tgl_pengembalian);
        $excel->setActiveSheetIndex(0)->setCellValue('D'.$numrow, $data->tgl_jth_tempo);
        $excel->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $data->judul);
        $excel->setActiveSheetIndex(0)->setCellValue('F'.$numrow, $data->nama_staf);
        $excel->setActiveSheetIndex(0)->setCellValue('G'.$numrow, $data->nama_member);
        $excel->setActiveSheetIndex(0)->setCellValue('H'.$numrow, $status);

        $excel->getActiveSheet()->getStyle('A'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('B'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('C'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('D'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('E'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('F'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('G'.$numrow)->applyFromArray($style_row);
        $excel->getActiveSheet()->getStyle('H'.$numrow)->applyFromArray($style_row);

        $no++;
        $numrow++;
      }

      $excel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
      $excel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
      $excel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
      $excel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
      $excel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
      $excel->getActiveSheet()->getColumnDimension('F')->setWidth(25);
      $excel->getActiveSheet()->getColumnDimension('G')->setWidth(25);
      $excel->getActiveSheet()->getColumnDimension('H')->setWidth(25);

      $excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);
      $excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);

      $excel->getActiveSheet(0)->setTitle('Laporan Pengembalian Buku');
      $excel->setActiveSheetIndex(0);

      header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      header('Content-Disposition: attachment; filename="Laporan Pengembalian Buku.xls"');

      header('Cache-Control: max-age=0');

      $write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
      $write->save('php://output');
    }
  }

?>
