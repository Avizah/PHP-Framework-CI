<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Member_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


	public function add()
	{
		return $this->db->insert('tb_member',array(
			'nama'=>$this->input->post('txtNamaMember',true),
      'alamat'=>$this->input->post('txtAlamatMember',true),
      'tempat_lahir'=>$this->input->post('txtTempatLahirMember',true),
      'tgl_lahir'=>$this->input->post('txtTglLahirMember',true),
      'jenkel'=>$this->input->post('cmbJenkelMember',true),
      'no_kontak'=>$this->input->post('txtNoKontakMember',true),
      'email'=>$this->input->post('txtEmailMember',true)
		));
	}

	public function edit($txtId)
	{
		$this->db->where('id_member', $txtId);
		return $this->db->update ('tb_member',array(
      'nama'=>$this->input->post('txtNamaMember',true),
      'alamat'=>$this->input->post('txtAlamatMember',true),
      'tempat_lahir'=>$this->input->post('txtTempatLahirMember',true),
      'tgl_lahir'=>$this->input->post('txtTglLahirMember',true),
      'jenkel'=>$this->input->post('cmbJenkelMember',true),
      'no_kontak'=>$this->input->post('txtNoKontakMember',true),
      'email'=>$this->input->post('txtEmailMember',true)
		));
	}

	public function getJson($offset,$limit,$field,$q='',$sort,$order){
		$sql = "SELECT * FROM tb_member WHERE 1=1 ";
		if($q!=''){
			if($field=='all'){
				$sql .=" AND nama LIKE '%{$q}%' ";
			}else {
				$sql .=" AND {$field} LIKE '%{$q}%' ";
			}
		}
		$result ['count'] = $this->db->query($sql)->num_rows();
		$sql .=" order by {$sort} {$order} ";
		$sql .=" LIMIT {$offset}, {$limit} ";
		$result ['data'] = $this->db->query($sql)->result();

		return $result;
	}

	public function delete($id)
	{
		return $this->db->delete('tb_member',array('id_member'=> $id));
	}

}
