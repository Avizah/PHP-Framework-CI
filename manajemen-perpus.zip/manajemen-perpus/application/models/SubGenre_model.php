<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class SubGenre_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function getGenre()
  {
    $this->db->order_by('nama_genre','ASC');
    $province=$this->db->get('tb_genre');

    return $province->result_array();
  }

	public function add()
	{
		return $this->db->insert('tb_subgenre', array(
			'kd_genre' => $this->input->post('cmbNamaGenre'),
			'nama_subgenre' => $this->input->post('txtNamaSubGenre',true)
		));
	}

	public function edit($txtId)
	{
		$this->db->where('kd_subgenre', $txtId);
		return $this->db->update('tb_subgenre', array(
      'nama_subgenre'=>$this->input->post('txtNamaSubGenre', true),
      'kd_genre' => $this->input->post('cmbNamaGenre', true)
    ));
	}

	public function delete($id)
	{
		return $this->db->delete('tb_subgenre', array('kd_subgenre' => $id));
	}

	public function getJson($offset, $limit, $field, $q='', $sort, $order)
	{
		$sql = " SELECT A.kd_subgenre, A.kd_genre, B.nama_genre, A.nama_subgenre FROM tb_subgenre A JOIN tb_genre B ON A.kd_genre=B.kd_genre WHERE 1=1 ";
		if($q!='')
		{
			if($field=='all')
			{
				$sql .=" AND nama_subgenre LIKE '%{$q}%' ";
			}
			else
			{
				$sql .=" AND {$field} LIKE '%{$q}%' ";
			}
		}
		$result['count'] = $this->db->query($sql)->num_rows();
		$sql .=" order by {$sort} {$order} ";
		$sql .=" LIMIT {$offset}, {$limit} ";
		$result['data'] = $this->db->query($sql)->result();
		$result['sql'] = $sql;

		return $result;
	}
}
