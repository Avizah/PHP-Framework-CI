<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Peminjaman_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function getData($tableName, $idField, $nameField, $fkField = '', $refId = '')
	{
		$sql = " SELECT {$idField}, {$nameField} FROM {$tableName} ";

		if ($fkField != '' && $refId != '')
			$sql .= " WHERE {$fkField} = {$refId} ";

		$sql .= " ORDER BY {$nameField} ASC ";
		$result = $this->db->query($sql);

		return $result->result_array();
	}

	public function add()
	{
    $data = json_decode($_POST['data']);
    $booklist = $data->booklist;
    $tglJthTempo = $data->tglJthTempo;

		$this->db->insert('tb_peminjaman',array(
			'tgl_pinjam' => $this->input->post('txtTglPeminjaman', true),
      'kd_member' => $this->input->post('cmbMember', true),
      'kd_staf' => $this->input->post('cmbStaf', true),
      'tgl_jth_tempo' => $tglJthTempo
		));

    $transactionId = $this->db->insert_id();
    foreach ($booklist as $book) {
      $this->db->insert('tb_detailpeminjaman', array(
        'kd_transaksi' => $transactionId,
        'kd_buku' => $book->txtBookId
      ));
    }

    return $this->db->affected_rows() > 0;
	}

  public function delete($id)
	{
		return $this->db->delete('tb_peminjaman',array('kd_transaksi' => $id));
	}

	public function getJson($offset,$limit,$field,$q='',$sort,$order){
		$sql = "SELECT A.kd_transaksi, A.tgl_pinjam, A.kd_member, A.kd_staf, A.tgl_jth_tempo,
              B.nama AS nama_member, C.nama AS nama_staf
              FROM tb_peminjaman A
              JOIN tb_member B ON A.kd_member = B.id_member
              JOIN tb_staf C ON A.kd_staf = C.id_staf WHERE 1=1 ";

		if($q!='') {
			if ($field=='all') {
				$sql .=" AND kd_transaksi LIKE '%{$q}%' ";
      } else if ($field == 'nama_member') {
        $sql .= " AND B.nama LIKE '%{$q}%' ";
      } else if ($field == 'nama_staf') {
        $sql .= " AND C.nama LIKE '%{$q}%' ";
			} else {
				$sql .=" AND {$field} LIKE '%{$q}%' ";
			}
		}

		$result['count'] = $this->db->query($sql)->num_rows();
		$sql .=" order by {$sort} {$order} ";
		$sql .=" LIMIT {$offset}, {$limit} ";
		$result['data'] = $this->db->query($sql)->result();

		return $result;
	}

  public function getBooklist($offset,$limit,$sort,$order, $kd_transaksi){
		$sql = " SELECT A.kd_buku, B.judul, B.edisi, C.nama AS nama_penulis
                FROM tb_detailpeminjaman A JOIN tb_buku B ON A.kd_buku = B.kd_buku
                JOIN tb_penulis C ON B.kd_penulis = C.kd_penulis
                WHERE A.kd_transaksi = {$kd_transaksi} ";

		$result['count'] = $this->db->query($sql)->num_rows();
		$sql .=" order by {$sort} {$order} ";
		$sql .=" LIMIT {$offset}, {$limit} ";
		$result['data'] = $this->db->query($sql)->result();

		return $result;
	}

  public function getBook()
  {
    $isbn = $this->input->post('txtIsbn', true);
    $sql = " SELECT A.kd_buku, A.kd_genre, A.kd_subgenre, A.judul, A.kd_penulis,
                A.kd_penerbit, A.tahun_terbit, A.edisi, A.isbn, B.nama AS nama_penulis,
                C.nama AS nama_penerbit, D.nama_genre, E.nama_subgenre, F.jml_stok
                FROM tb_buku A JOIN tb_penulis B ON A.kd_penulis = B.kd_penulis
                JOIN tb_penerbit C ON A.kd_penerbit = C.kd_penerbit
                JOIN tb_genre D ON A.kd_genre = D.kd_genre
                JOIN tb_subgenre E ON A.kd_subgenre = E.kd_subgenre
                JOIN tb_stokbuku F ON A.kd_buku = F.kd_buku WHERE A.isbn = {$isbn} ";

    $result = $this->db->query($sql)->row();
    return $result;
  }

  public function getReportData()
  {
    $tglAwal = $this->input->post('txtTglAwal', true);
    $tglAkhir = $this->input->post('txtTglAkhir', true);
    $sql = " SELECT A.kd_transaksi, A.tgl_pinjam, A.tgl_jth_tempo, B.status, C.judul,
                D.nama AS nama_staf, E.nama AS nama_member
                FROM tb_peminjaman A JOIN tb_detailpeminjaman B ON A.kd_transaksi = B.kd_transaksi
                JOIN tb_buku C ON B.kd_buku = C.kd_buku
                JOIN tb_staf D ON A.kd_staf = D.id_staf
                JOIN tb_member E ON A.kd_member = E.id_member
                WHERE A.tgl_pinjam BETWEEN '{$tglAwal}' AND '{$tglAkhir}' ORDER BY A.kd_transaksi ASC ";

    return $this->db->query($sql)->result();
  }
}
