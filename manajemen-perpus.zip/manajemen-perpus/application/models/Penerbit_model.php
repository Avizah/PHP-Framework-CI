<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Penerbit_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


	public function add()
	{
		return $this->db->insert('tb_penerbit',array(
			'nama'=>$this->input->post('txtNamaPenerbit',true),
      'alamat'=>$this->input->post('txtAlamatPenerbit',true),
      'no_kontak'=>$this->input->post('txtNoKontakPenerbit',true),
      'email'=>$this->input->post('txtEmailPenerbit',true)
		));
	}

	public function edit($txtId)
	{
		$this->db->where('kd_penerbit', $txtId);
		return $this->db->update ('tb_penerbit',array(
      'nama'=>$this->input->post('txtNamaPenerbit',true),
      'alamat'=>$this->input->post('txtAlamatPenerbit',true),
      'no_kontak'=>$this->input->post('txtNoKontakPenerbit',true),
      'email'=>$this->input->post('txtEmailPenerbit',true)
		));
	}

	public function getJson($offset,$limit,$field,$q='',$sort,$order){
		$sql = "SELECT * FROM tb_penerbit WHERE 1=1 ";
		if($q!=''){
			if($field=='all'){
				$sql .=" AND nama LIKE '%{$q}%' ";
			}else {
				$sql .=" AND {$field} LIKE '%{$q}%' ";
			}
		}
		$result ['count'] = $this->db->query($sql)->num_rows();
		$sql .=" order by {$sort} {$order} ";
		$sql .=" LIMIT {$offset}, {$limit} ";
		$result ['data'] = $this->db->query($sql)->result();

		return $result;
	}

	public function delete($id)
	{
		return $this->db->delete('tb_penerbit',array('kd_penerbit'=> $id));
	}

}
