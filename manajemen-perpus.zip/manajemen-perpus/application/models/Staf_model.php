<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Staf_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


	public function add()
	{
    $password = md5($this->input->post('txtPasswordStaf'));
		return $this->db->insert('tb_staf',array(
			'nama'=>$this->input->post('txtNamaStaf',true),
      'alamat'=>$this->input->post('txtAlamatStaf',true),
      'tempat_lahir'=>$this->input->post('txtTempatLahirStaf',true),
      'tgl_lahir'=>$this->input->post('txtTglLahirStaf',true),
      'jenkel'=>($this->input->post('cmbJenkelStaf',true) == 'Pria') ? 'P' : 'W',
      'no_kontak'=>$this->input->post('txtNoKontakStaf',true),
      'email'=>$this->input->post('txtEmailStaf',true),
      'level'=>$this->input->post('cmbLevelStaf', true),
      'user'=>$this->input->post('txtUserStaf',true),
      'password'=>$password
		));
	}

	public function edit($txtId)
	{
    $passwordLama = $this->input->post('txtPasswordLama', true);
    $password = $this->input->post('txtPasswordStaf', true);

    $this->db->where('id_staf', $txtId);
    return $this->db->update ('tb_staf',array(
      'nama'=>$this->input->post('txtNamaStaf',true),
      'alamat'=>$this->input->post('txtAlamatStaf',true),
      'tempat_lahir'=>$this->input->post('txtTempatLahirStaf',true),
      'tgl_lahir'=>$this->input->post('txtTglLahirStaf',true),
      'jenkel'=>($this->input->post('cmbJenkelStaf',true) == 'Pria') ? 'P' : 'W',
      'no_kontak'=>$this->input->post('txtNoKontakStaf',true),
      'email'=>$this->input->post('txtEmailStaf',true),
      'level'=>$this->input->post('cmbLevelStaf', true),
      'user'=>$this->input->post('txtUserStaf',true),
      'password'=>($password == $passwordLama) ? $passwordLama : md5($password)
		));
	}

	public function getJson($offset,$limit,$field,$q='',$sort,$order){
		$sql = " SELECT * FROM tb_staf WHERE 1=1 ";
		if($q!=''){
			if($field == 'all'){
				$sql .= " AND nama LIKE '%{$q}%' ";
			}else {
				$sql .= " AND {$field} LIKE '%{$q}%' ";
			}
		}
		$result ['count'] = $this->db->query($sql)->num_rows();
		$sql .=" order by {$sort} {$order} ";
		$sql .=" LIMIT {$offset}, {$limit} ";
		$result ['data'] = $this->db->query($sql)->result();

		return $result;
	}

	public function delete($id)
	{
		return $this->db->delete('tb_staf',array('id_staf'=> $id));
	}

}
