<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pengembalian_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function getData($tableName, $idField, $nameField, $fkField = '', $refId = '')
	{
		$sql = " SELECT {$idField}, {$nameField} FROM {$tableName} ";

		if ($fkField != '' && $refId != '')
			$sql .= " WHERE {$fkField} = {$refId} ";

		$sql .= " ORDER BY {$nameField} ASC ";
		$result = $this->db->query($sql);

		return $result->result_array();
	}

	public function add()
	{
    $data = json_decode($_POST['data']);
    $booklist = $data->booklist;

		$this->db->insert('tb_pengembalian',array(
			'tgl_pengembalian' => $this->input->post('txtTglPengembalian', true),
      'kd_member' => $this->input->post('cmbMember', true),
      'kd_staf' => $this->input->post('cmbStaf', true),
		));

    $transactionId = $this->db->insert_id();
    foreach ($booklist as $book) {
      $this->db->insert('tb_detailpengembalian', array(
        'kd_transaksi' => $transactionId,
        'kd_peminjaman' => $book->txtIdPeminjaman,
        'kd_buku' => $book->txtBookId
      ));
    }

    return $this->db->affected_rows() > 0;
	}

  public function delete($id)
	{
		return $this->db->delete('tb_pengembalian',array('kd_transaksi' => $id));
	}

	public function getJson($offset,$limit,$field,$q='',$sort,$order){
		$sql = "SELECT A.kd_transaksi, A.tgl_pengembalian, A.kd_member, A.kd_staf,
              B.nama AS nama_member, C.nama AS nama_staf
              FROM tb_pengembalian A
              JOIN tb_member B ON A.kd_member = B.id_member
              JOIN tb_staf C ON A.kd_staf = C.id_staf WHERE 1=1 ";

		if($q!='') {
			if ($field=='all') {
				$sql .=" AND kd_transaksi LIKE '%{$q}%' ";
      } else if ($field == 'nama_member') {
        $sql .= " AND B.nama LIKE '%{$q}%' ";
      } else if ($field == 'nama_staf') {
        $sql .= " AND C.nama LIKE '%{$q}%' ";
			} else {
				$sql .=" AND {$field} LIKE '%{$q}%' ";
			}
		}

		$result['count'] = $this->db->query($sql)->num_rows();
		$sql .=" order by {$sort} {$order} ";
		$sql .=" LIMIT {$offset}, {$limit} ";
		$result['data'] = $this->db->query($sql)->result();

		return $result;
	}

  public function getBooklist($offset,$limit,$sort,$order, $kd_transaksi){
		$sql = " SELECT A.kd_peminjaman, A.kd_buku, B.tgl_jth_tempo, C.judul
                FROM tb_detailpengembalian A JOIN tb_peminjaman B ON A.kd_peminjaman = B.kd_transaksi
                JOIN tb_buku C ON A.kd_buku = C.kd_buku WHERE A.kd_transaksi = {$kd_transaksi} ";

		$result['count'] = $this->db->query($sql)->num_rows();
		$sql .=" order by {$sort} {$order} ";
		$sql .=" LIMIT {$offset}, {$limit} ";
		$result['data'] = $this->db->query($sql)->result();

		return $result;
	}

  public function getBook()
  {
    $isbn = $this->input->post('isbn', true);
    $pengembali = $this->input->post('member', true);

    $sql = " SELECT A.kd_transaksi, A.tgl_jth_tempo, B.kd_buku, C.judul
                FROM tb_peminjaman A JOIN tb_detailpeminjaman B ON B.kd_transaksi = A.kd_transaksi
                JOIN tb_buku C ON B.kd_buku = C.kd_buku
                JOIN tb_penulis D ON C.kd_penulis = D.kd_penulis
                WHERE A.kd_member = {$pengembali} AND C.isbn = '{$isbn}' AND B.status = 'F' ";

    $result = $this->db->query($sql)->row();
    return $result;
  }

  public function getReportData()
  {
    $tglAwal = $this->input->post('txtTglAwal', true);
    $tglAkhir = $this->input->post('txtTglAkhir', true);
    $sql = " SELECT A.kd_transaksi, A.tgl_pengembalian, C.tgl_jth_tempo, D.judul,
                E.nama AS nama_staf, F.nama AS nama_member
                FROM tb_pengembalian A JOIN tb_detailpengembalian B ON A.kd_transaksi = B.kd_transaksi
                JOIN tb_peminjaman C ON B.kd_peminjaman = C.kd_transaksi
                JOIN tb_buku D ON B.kd_buku = D.kd_buku
                JOIN tb_staf E ON A.kd_staf = E.id_staf
                JOIN tb_member F ON A.kd_member = F.id_member
                WHERE A.tgl_pengembalian BETWEEN '{$tglAwal}' AND '{$tglAkhir}' ORDER BY A.kd_transaksi ASC ";

    return $this->db->query($sql)->result();
  }
}
