<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

  class Buku_model extends CI_Model
  {
    public function __construct()
    {
      parent::__construct();
      $this->load->database();
    }

    public function getData($tableName, $idField, $nameField, $fkField = '', $refId = '')
    {
      $sql = " SELECT {$idField}, {$nameField} FROM {$tableName} ";

      if ($fkField != '' && $refId != '')
        $sql .= " WHERE {$fkField} = {$refId} ";

      $sql .= " ORDER BY {$nameField} ASC ";
      $result = $this->db->query($sql);
      return $result->result_array();
    }

    public function add()
  	{
  		$this->db->insert('tb_buku', array(
  			'isbn' => $this->input->post('txtIsbn', true),
        'judul' => $this->input->post('txtJudulBuku', true),
        'edisi' => $this->input->post('txtEdisi', true),
        'kd_penulis' => $this->input->post('cmbPenulis', true),
        'kd_penerbit' => $this->input->post('cmbPenerbit', true),
        'tahun_terbit' => $this->input->post('txtThnTerbit', true),
        'kd_genre' => $this->input->post('cmbGenre', true),
        'kd_subgenre' => $this->input->post('cmbSubGenre', true)
  		));
      return $this->db->insert('tb_stokbuku', array(
        'kd_buku' => $this->db->insert_id(),
        'jml_stok' => $this->input->post('txtStok', true)
      ));
  	}

  	public function edit($txtId)
  	{
  		$this->db->where('kd_buku', $txtId);
      $this->db->update('tb_buku', array(
  			'isbn' => $this->input->post('txtIsbn', true),
        'judul' => $this->input->post('txtJudulBuku', true),
        'edisi' => $this->input->post('txtEdisi', true),
        'kd_penulis' => $this->input->post('cmbPenulis', true),
        'kd_penerbit' => $this->input->post('cmbPenerbit', true),
        'tahun_terbit' => $this->input->post('txtThnTerbit', true),
        'kd_genre' => $this->input->post('cmbGenre', true),
        'kd_subgenre' => $this->input->post('cmbSubGenre', true)
  		));

      $this->db->where('kd_buku', $txtId);
      return $this->db->update('tb_stokbuku', array(
        'jml_stok' => $this->input->post('txtStok', true)
      ));
  	}

  	public function delete($id)
  	{
      $this->db->delete('tb_stokbuku', array('kd_buku' => $id));
  		return $this->db->delete('tb_buku', array('kd_buku' => $id));
  	}

  	public function getJson($offset, $limit, $field, $q='', $sort, $order)
  	{
  		$sql = " SELECT A.kd_buku, A.kd_genre, A.kd_subgenre, A.judul, A.kd_penulis,
                  A.kd_penerbit, A.tahun_terbit, A.edisi, A.isbn, B.nama AS nama_penulis,
                  C.nama AS nama_penerbit, D.nama_genre, E.nama_subgenre, F.jml_stok
                  FROM tb_buku A JOIN tb_penulis B ON A.kd_penulis = B.kd_penulis
                  JOIN tb_penerbit C ON A.kd_penerbit = C.kd_penerbit
                  JOIN tb_genre D ON A.kd_genre = D.kd_genre
                  JOIN tb_subgenre E ON A.kd_subgenre = E.kd_subgenre
                  JOIN tb_stokbuku F ON A.kd_buku = F.kd_buku WHERE 1=1 ";
  		if($q!='')
  		{
  			if($field == 'all')
  			{
  				$sql .= " AND judul LIKE '%{$q}%' ";
  			}
  			else if ($field == 'nama_penulis')
  			{
  				$sql .= " AND B.nama LIKE '%{$q}%' ";
  			}
        else if ($field == 'nama_penerbit')
  			{
  				$sql .= " AND C.nama LIKE '%{$q}%' ";
  			}
        else
  			{
  				$sql .= " AND {$field} LIKE '%{$q}%' ";
  			}
  		}
  		$result['count'] = $this->db->query($sql)->num_rows();
  		$sql .= " ORDER BY {$sort} {$order} ";
  		$sql .= " LIMIT {$offset}, {$limit} ";
  		$result['data'] = $this->db->query($sql)->result();

  		return $result;
  	}
  }

?>
