<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Penulis_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}


	public function add()
	{
		return $this->db->insert('tb_penulis',array(
			'nama'=>$this->input->post('txtNamaPenulis',true),
      'alamat'=>$this->input->post('txtAlamatPenulis',true),
      'tempat_lahir'=>$this->input->post('txtTempatLahirPenulis',true),
      'tgl_lahir'=>$this->input->post('txtTglLahirPenulis',true),
      'jenkel'=>$this->input->post('cmbJenkelPenulis',true),
      'no_kontak'=>$this->input->post('txtNoKontakPenulis',true),
      'email'=>$this->input->post('txtEmailPenulis',true)
		));
	}

	public function edit($txtId)
	{
		$this->db->where('kd_penulis', $txtId);
		return $this->db->update ('tb_penulis',array(
      'nama'=>$this->input->post('txtNamaPenulis',true),
      'alamat'=>$this->input->post('txtAlamatPenulis',true),
      'tempat_lahir'=>$this->input->post('txtTempatLahirPenulis',true),
      'tgl_lahir'=>$this->input->post('txtTglLahirPenulis',true),
      'jenkel'=>$this->input->post('cmbJenkelPenulis',true),
      'no_kontak'=>$this->input->post('txtNoKontakPenulis',true),
      'email'=>$this->input->post('txtEmailPenulis',true)
		));
	}

	public function getJson($offset,$limit,$field,$q='',$sort,$order){
		$sql = "SELECT * FROM tb_penulis WHERE 1=1 ";
		if($q!=''){
			if($field=='all'){
				$sql .=" AND nama LIKE '%{$q}%' ";
			}else {
				$sql .=" AND {$field} LIKE '%{$q}%' ";
			}
		}
		$result ['count'] = $this->db->query($sql)->num_rows();
		$sql .=" order by {$sort} {$order} ";
		$sql .=" LIMIT {$offset}, {$limit} ";
		$result ['data'] = $this->db->query($sql)->result();

		return $result;
	}

	public function delete($id)
	{
		return $this->db->delete('tb_penulis',array('kd_penulis'=> $id));
	}

}
