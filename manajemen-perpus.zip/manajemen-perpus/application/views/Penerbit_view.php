<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Pemrograman Web 2</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/default/easyui.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/icon.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
    <script src="<?php echo base_url('assets/easyui/jquery.min.js') ?>" charset="utf-8"></script>
    <script src="<?php echo base_url('assets/easyui/jquery.easyui.min.js') ?>" charset="utf-8"></script>

    <script type="text/javascript">
      var btn = [];
      var url;

      var search = {
        iconCls: 'icon-search',
        handler:function()
        {
          $('#search-dialog').dialog('open').dialog('setTitle','Pencarian Data');
          $('#sfm').form('clear');
        }
      };
      btn.push(search);

      var add = {
        text: 'Tambah Data',
        iconCls: 'icon-add',
        handler: function() {
          $('#form-dialog').dialog('open').dialog('setTitle','Tambah Data');
          $('#fm').form('clear');
          url='<?php echo site_url("Penerbit/add"); ?>';
        }
      };
      btn.push(add);

      var edit = {
        text: 'Ubah Data',
        iconCls: 'icon-edit',
        handler: function() {
          var row = jQuery('#dlg').datagrid('getSelected');
          if (!row)
          {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
          $('#form-dialog').dialog('setTitle', 'Penerbit Buku - Ubah Data').dialog('open');
          jQuery('#fm').form('load',row);
          url = '<?php echo site_url('Penerbit/edit'); ?>/' + row.txtId;

        }
      };
      btn.push(edit);

      var remove = {
        text: 'Hapus Data',
        iconCls: 'icon-remove',
        handler:function()
        {
          var row = $('#dlg').datagrid('getSelected');
          if (row)
          {
            $.messager.confirm('Confirm','Yakin mau hapus record ' +row.txtNamaPenerbit+'?',function(r)
            {
              if (r)
              {
                $.post('<?php echo site_url('Penerbit/delete'); ?>',{id:row.txtId},function(result)
                {
                  var result = eval('('+result+')');
                  if (result.success)
                  {
                    $.messager.alert('Sukses!','Baris '+row.txtNamaPenerbit+' berhasil dihapus!','info');
                    $('#dlg').datagrid('reload');
                  } else
                  {
                    $.messager.show
                    ({
                      title: 'Error',
                      msg: result.msg
                    });
                  }
                });//,'json'
               }
            });
          }else
          {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
        }
      };
      btn.push(remove);

      $(function() {
        var pager = $('#dlg').datagrid('getPager');
        pager.pagination({
          buttons: btn
        });
      });

      function saveData()
      {
				$('#fm').form('submit',
        {
					url:url,
					onSubmit: function()
          {
						return $(this).form('validate');
					},
					success: function(result)
          {
						var result = eval ('('+result+')');
						if(result.success)
            {
							$('#form-dialog').dialog('close');
							$('#dlg').datagrid('reload');
						} else
            {
							$.messager.show
              ({
								title: 'Error',
								msg: result.msg
							});
						}
					}
				});
			}

			function doSearch (value,name)
      {
				if (value !="")
				{
					$('#dlg').datagrid('load',{
						findId: name,
						findNilai: value
					});
				}
			}

    </script>
  </head>
  <body>
    <table id="dlg" class="easyui-datagrid"
           style="width: auto; height: 500px;"
           url="<?php echo site_url('Penerbit/getJson'); ?>"
           toolbar="#toolbar"
           footer="#footer"
           title="Data Penerbit Buku"
           fit="true"
           pagination="true"
           pageSize="10" pageList="[10, 20, 30, 50]"
           stripped="true" nowrap="false"
           fitColumns="true" singleSelect="true" remoteSort="false"
           rowNumbers="true">
      <thead>
        <tr>
          <th data-options="field: 'txtId', width: 50, sortable: true, hidden: true">Kode Penerbit</th>
          <th data-options="field: 'txtNamaPenerbit', width: 100, sortable: true, align: 'left', halign: 'center'">Nama Penerbit </th>
          <th data-options="field: 'txtAlamatPenerbit', width: 100, sortable: true, align: 'left', halign: 'center'">Alamat Penerbit</th>
          <th data-options="field: 'txtNoKontakPenerbit', width: 100, sortable: true, align: 'left', halign: 'center'">No Kontak Penerbit</th>
          <th data-options="field: 'txtEmailPenerbit', width: 100, sortable: true, align: 'left', halign: 'center'">Email Penerbit</th>
        </tr>
      </thead>
    </table>

    <div id="form-dialog" class="easyui-dialog"
         style="width: 400px; padding: 12px;"
         buttons="#dlg-btn" closed="true">
      <form id="fm" action="index.html" method="post" novalidate>
        <table width="100%" class="form-table">
          <tr>
            <td>
              <input type="hidden" name="txtId" id="txtId">
            </td>
          </tr>
          <tr>
            <td>
              <label>Nama Penerbit</label>
            </td>
            <td>
              <input type="text" name="txtNamaPenerbit" id="txtNamaPenerbit"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Alamat Penerbit</label>
            </td>
            <td>
              <input type="text" name="txtAlamatPenerbit" id="txtAlamatPenerbit"
                     class="easyui-validatebox textbox"
                     maxlength="50" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>No Kontak Penerbit</label>
            </td>
            <td>
              <input type="text" name="txtNoKontakPenerbit" id="txtNoKontakPenerbit"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Email Penerbit</label>
            </td>
            <td>
              <input type="text" name="txtEmailPenerbit" id="txtEmailPenerbit"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
        </table>
      </form>
    </div>
    <div id="dlg-btn">
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-ok" onclick="saveData()">Simpan</a>
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-cancel" onclick="javascript:$('#form-dialog').dialog('close')">Batal</a>
    </div>

    <div id="search-dialog" class="easyui-dialog"
         style="width: 400px; height: auto; padding: 12px;"
         buttons="#src-btn" closed="true">
      <form id="sfm" action="index.html" method="post">
        <input type="text" class="easyui-searchbox"
               style="width: 100%;"
               data-options="prompt: 'Masukkan kata kunci pencarian', menu: '#mm', searcher: doSearch">

        <div id="mm">
          <div data-options="name: 'all', iconCls: 'icon-ok'">Semua</div>
          <div data-options="name: 'nama', iconCls: 'icon-ok'">Nama Penerbit</div>
          <div data-options="name: 'alamat', iconCls: 'icon-ok'">Alamat Penerbit</div>
          <div data-options="name: 'no_kontak', iconCls: 'icon-ok'">No Kontak Penerbit</div>
          <div data-options="name: 'email', iconCls: 'icon-ok'">Email Penerbit</div>
        </div>
      </form>
    </div>

  </body>
</html>
