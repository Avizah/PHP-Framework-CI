<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Pemrograman Web 2</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/default/easyui.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/icon.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
    <script src="<?php echo base_url('assets/easyui/jquery.min.js') ?>" charset="utf-8"></script>
    <script src="<?php echo base_url('assets/easyui/jquery.easyui.min.js') ?>" charset="utf-8"></script>

    <script type="text/javascript">
      $.fn.combobox.defaults.width = "99%";

      var btn = [];
      var bookbtn = [];
      var url;
      var booklist = {total: 0, rows: []};
      var dialogType;

      function removeElm(array, element) {
        const index = array.map(function(e) { return e.txtBookId; }).indexOf(element)

        if (index !== -1) {
          array.splice(index, 1);
        }
      }

      var removebook = {
        iconCls: 'icon-remove',
        handler: function() {
          var row = $('#booklist').datagrid('getSelected');
          if (row) {
            $.messager.confirm('Confirm','Yakin mau hapus record ' + row.txtJudulBuku +'?',function(r) {
              if (r) {
                removeElm(booklist['rows'], row.txtBookId);
                booklist['total']--;
                $('#booklist').datagrid('loadData', booklist);
              }
            });
          } else {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
        }
      };
      bookbtn.push(removebook);

      var search = {
        iconCls: 'icon-search',
        handler:function()
        {
          $('#search-dialog').dialog('setTitle','Pengembalian - Pencarian Data').dialog('open');
          $('#sfm').form('clear');
        }
      };
      btn.push(search);

      var add = {
        text: 'Tambah Data',
        iconCls: 'icon-add',
        handler: function() {
          booklist = {total: 0, rows: []};
          $('#form-dialog').dialog('setTitle','Pengembalian - Tambah Data').dialog('open');
          $('#fm').form('clear');
          url='<?php echo site_url("Pengembalian/add"); ?>';
          dialogType = 'add';
          $('#booklist').datagrid('loadData', []);

          formEnabled(true);
        }
      };
      btn.push(add);

      var view = {
        text: 'Lihat Detail',
        iconCls: 'icon-edit',
        handler: function() {
          var row = $('#dlg').datagrid('getSelected');
          if (!row)
          {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
          $('#form-dialog').dialog('setTitle', 'Pengembalian - Detail Data').dialog('open');
          jQuery('#fm').form('load',row);
          url = '<?php echo site_url('Pengembalian/getBooklist'); ?>/' + row.txtId;
          dialogType = 'view';
          $('#booklist').datagrid('load', url);

          formEnabled(false);
        }
      };
      btn.push(view);

      var remove = {
        text: 'Hapus Data',
        iconCls: 'icon-remove',
        handler:function()
        {
          var row = $('#dlg').datagrid('getSelected');
          if (row)
          {
            $.messager.confirm('Confirm','Yakin mau hapus record transaksi ' +row.txtId+'?',function(r)
            {
              if (r)
              {
                $.post('<?php echo site_url('Pengembalian/delete'); ?>',{id:row.txtId},function(result)
                {
                  var result = eval('('+result+')');
                  if (result.success)
                  {
                    $.messager.alert('Sukses!','Transaksi '+row.txtId+' berhasil dihapus!','info');
                    $('#dlg').datagrid('reload');
                  } else
                  {
                    $.messager.show
                    ({
                      title: 'Error',
                      msg: result.msg
                    });
                  }
                });
               }
            });
          }else
          {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
        }
      };
      btn.push(remove);

      var report = {
        text: 'Cetak Laporan',
        iconCls: 'icon-print',
        handler: function() {
          $('#report-dialog').dialog('open');
        }
      };
      btn.push(report);

      $(function() {
        var pager = $('#dlg').datagrid('getPager');
        pager.pagination({
          buttons: btn
        });
      });

      function formEnabled(isEnabled) {
        // Enable/disable datagrid buttons
        var pager = $('#booklist').datagrid('getPager');
        pager.pagination({
          buttons: (isEnabled) ? bookbtn : []
        });

        // Enable/disable form component
        $('#txtTglPengembalian').datebox('readonly', !isEnabled);
        $('#cmbMember').combobox('readonly', !isEnabled);
        $('#cmbStaf').combobox('readonly', !isEnabled);
        $('#txtIsbn').textbox('readonly', !isEnabled);
        $('#btnAddBook').linkbutton((isEnabled) ? 'enable' : 'disable');
      }
    </script>
  </head>
  <body>
    <table id="dlg" class="easyui-datagrid"
           style="width: auto; height: 500px;"
           url="<?php echo site_url('Pengembalian/getJson'); ?>"
           toolbar="#toolbar"
           footer="#footer"
           title="Data Pengembalian"
           fit="true"
           pagination="true"
           pageSize="10" pageList="[10, 20, 30, 50]"
           stripped="true" nowrap="false"
           fitColumns="true" singleSelect="true" remoteSort="false"
           rowNumbers="true">
      <thead>
        <tr>
          <th data-options="field: 'cmbMember', width: 50, sortable: true, hidden: true">KD Member Pengembali</th>
          <th data-options="field: 'cmbStaf', width: 100, sortable: true, hidden: true">KD Staf</th>
          <th data-options="field: 'txtId', width: 100, sortable: true, align: 'left', halign: 'center'">Kode Transaksi</th>
          <th data-options="field: 'txtTglPengembalian', width: 100, sortable: true, align: 'left', halign: 'center'">Tanggal Pengembalian</th>
          <th data-options="field: 'txtNamaMember', width: 100, sortable: true, align: 'left', halign: 'center'">Nama Member</th>
          <th data-options="field: 'txtNamaStaf', width: 100, sortable: true, align: 'left', halign: 'center'">Nama Staf</th>
        </tr>
      </thead>
    </table>

    <div id="form-dialog" class="easyui-dialog"
         style="width: 600px; padding: 12px;"
         buttons="#dlg-btn" closed="true">
      <form id="fm" action="index.html" method="post" novalidate>
        <table width="100%" class="form-table">
          <tr>
            <td>
              <input type="hidden" name="data" id="data">
            </td>
            <td>
              <input type="hidden" name="txtId" id="txtId">
            </td>
          </tr>
          <tr>
            <td>
              <label>Tanggal Pengembalian</label>
            </td>
            <td colspan="2">
              <input type="text" name="txtTglPengembalian" id="txtTglPengembalian"
                     class="easyui-datebox"
                     data-options="formatter: dateFormatter, parser: dateParser" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Pengembali</label>
            </td>
            <td colspan="2">
              <select class="easyui-combobox" name="cmbMember" id="cmbMember"
                      data-options="prompt: '-- PILIH --', value: ''" required>
                <?php
                  foreach ($daftarPengembali as $pengembali) {
                    echo "<option value='$pengembali[id_member]'>$pengembali[nama]</option>";
                  }
                ?>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>Staf</label>
            </td>
            <td colspan="2">
              <select class="easyui-combobox" name="cmbStaf" id="cmbStaf"
                      data-options="prompt: '-- PILIH --', value: ''" required>
                      <?php
                        foreach ($daftarStaf as $staf) {
                          echo "<option value='$staf[id_staf]'>$staf[nama]</option>";
                        }
                      ?>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>ISBN Buku</label>
            </td>
            <td>
              <input type="text" name="txtIsbn" id="txtIsbn"
                     class="easyui-textbox textbox" style="width: 98%; height: 20px;"
                     maxlength="13">
            </td>
            <td>
              <a id="btnAddBook" href="javascript:void(0);" class="easyui-linkbutton"
                 iconCls="icon-add" onclick="saveData('book')"></a>
            </td>
          </tr>
        </table>
        <label>Daftar Buku Dikembalikan</label>
        <table id="booklist" class="easyui-datagrid"
               style="width: 100%; height: 200px;"
               pagination="true"
               pageSize="10" pageList="[10, 20, 30, 50]"
               stripped="true" nowrap="false"
               fitColumns="true" singleSelect="true" remoteSort="false"
               rowNumbers="true">
          <thead>
            <tr>
              <th data-options="field: 'txtIdPeminjaman', width: 50, sortable: true, hidden: true">ID Peminjaman</th>
              <th data-options="field: 'txtBookId', width: 50, sortable: true, hidden: true">ID Buku</th>
              <th data-options="field: 'txtJudulBuku', width: 100, sortable: true, align: 'left', halign: 'center'">Judul Buku</th>
              <th data-options="field: 'txtTglJatuhTempo', width: 100, sortable: true, align: 'left', halign: 'center'">Tanggal Jatuh Tempo</th>
            </tr>
          </thead>
        </table>
      </form>
    </div>
    <div id="dlg-btn">
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-ok" onclick="saveData(dialogType)">Simpan</a>
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-cancel" onclick="javascript:$('#form-dialog').dialog('close')">Batal</a>
    </div>

    <div id="search-dialog" class="easyui-dialog"
         style="width: 400px; height: auto; padding: 12px;"
         buttons="#src-btn" closed="true">
      <form id="sfm" action="index.html" method="post">
        <input type="text" class="easyui-searchbox"
               style="width: 100%;"
               data-options="prompt: 'Masukkan kata kunci pencarian', menu: '#mm', searcher: doSearch">

        <div id="mm">
          <div data-options="name: 'all', iconCls: 'icon-ok'">Semua</div>
          <div data-options="name: 'kd_transaksi', iconCls: 'icon-ok'">KD Transaksi Pengembalian</div>
          <div data-options="name: 'nama_member', iconCls: 'icon-ok'">Nama Member</div>
          <div data-options="name: 'nama_staf', iconCls: 'icon-ok'">Nama Staf</div>
        </div>
      </form>
    </div>

    <div id="report-dialog" class="easyui-dialog"
         title="Laporan Transaksi Pengembalian"
         style="width: 400px; padding: 12px;"
         buttons="#report-buttons" closed="true">
      <form id="rfm" name="rfm" method="post">
        <table width="100%" class="form-table">
          <tr>
            <td>
              <label>Tipe Laporan</label>
            </td>
            <td>
              <select class="easyui-combobox" name="cmbFileType" id="cmbFileType"
                      data-options="prompt: '-- PILIH --', value: 'pdf'" required>
                <option value="pdf">PDF</option>
                <option value="excel">Excel</option>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>Dari Tanggal</label>
            </td>
            <td>
              <input type="text" name="txtTglAwal" id="txtTglAwal"
                     class="easyui-datebox"
                     data-options="formatter: dateFormatter, parser: dateParser" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Sampai Tanggal</label>
            </td>
            <td>
              <input type="text" name="txtTglAkhir" id="txtTglAkhir"
                     class="easyui-datebox"
                     data-options="formatter: dateFormatter, parser: dateParser" required>
            </td>
          </tr>
        </table>
      </form>
    </div>

    <div id="report-buttons">
      <a class="easyui-linkbutton" iconCls="icon-ok"
         href="javascript:void(0);" onclick="prosesReport()">Ok</a>
      <a class="easyui-linkbutton" iconCls="icon-cancel"
         href="javascript:void(0);" onclick="javascript: $('#report-dialog').dialog('close')">Tutup</a>
    </div>

    <script type="text/javascript">
      function saveData(type)
      {
        if (type == 'add') {
          var params = {booklist: booklist['rows']}
          var str = JSON.stringify(params);
          $('#data').val(str);
          $('#fm').form('submit', {
            url: url,
            onSubmit: function()
            {
              return $(this).form('validate');
            },
            success: function(result)
            {
              var result = eval ('('+result+')');
              if(result.success) {
                $('#form-dialog').dialog('close');
                $('#dlg').datagrid('reload');
              }
              else {
                $.messager.show
                ({
                  title: 'Error',
                  msg: result.msg
                });
              }
            }
          });
        } else if (type == 'view') {
          $('#form-dialog').dialog('close');
        } else if (type == 'book') {
          var isbn = $('#txtIsbn').textbox('getValue');
          var pengembali = $('#cmbMember').combobox('getValue');
          $.post('<?php echo site_url("Pengembalian/getBook"); ?>', {isbn: isbn, member: pengembali}, function(result) {
            var result = eval('('+result+')');
            if (result['success']) {
              booklist['total']++;
              booklist['rows'].push({
                txtIdPeminjaman: result['txtIdPeminjaman'],
                txtBookId: result['txtBookId'],
                txtJudulBuku: result['txtJudulBuku'],
                txtTglJatuhTempo: result['txtTglJatuhTempo']
              });
              $('#booklist').datagrid('loadData', booklist);
              $('#txtIsbn').textbox('clear');
            } else {
              $.messager.show({
                title: 'Error',
                msg: result.msg
              });
              $('#txtIsbn').textbox('clear').textbox('textbox').focus();
            }
          });
        }
      }

      function doSearch (value,name)
      {
        if (value !="")
        {
          $('#dlg').datagrid('load',{
            findId: name,
            findNilai: value
          });
        }
      }

      function dateFormatter(date) {
        var y = date.getFullYear();
        var m = date.getMonth()+1;
        var d = date.getDate();
        return y + '-' + (m<10?('0'+m):m) + '-' + (d<10?('0'+d):d);
      }

      function dateParser(s) {
        if (!s) return new Date();
        var ss = (s.split('-'));
        var y = parseInt(ss[0],10);
        var m = parseInt(ss[1],10);
        var d = parseInt(ss[2],10);
        if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
          return new Date(y, m-1, d);
        } else {
          return new Date();
        }
      }

      function getBook() {
        // $('#book-fm').form('submit', {
        //   url: '<?php echo site_url("Peminjaman/getBook"); ?>',
        //   onSubmit: function() {
        //     return $(this).form('validate');
        //   },
        //   success: function(result) {
        //     var result = eval('('+result+')');
        //     if (result['success']) {
        //       for (i in result) {
        //         $('input[name = "' + i + '"]').val(result[i]);
        //       }
        //       $('#saveBookData').linkbutton('enable');
        //     } else {
        //       $('#saveBookData').linkbutton('disable');
        //       $('#book-fm').form('clear');
        //       $.messager.show({
        //         title: 'Error',
        //         msg: result.msg
        //       });
        //     }
        //   }
        // });
      }

      function prosesReport() {
        url = '<?php echo site_url("Pengembalian/export"); ?>';
        $('#rfm').form('submit', {
          url: url,
          onSubmit: function() {
            $('#report-dialog').dialog('close');
            return $(this).form('validate');
          }
        });
      }
    </script>
  </body>
</html>
