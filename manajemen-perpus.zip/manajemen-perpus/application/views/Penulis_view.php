<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Pemrograman Web 2</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/default/easyui.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/icon.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
    <script src="<?php echo base_url('assets/easyui/jquery.min.js') ?>" charset="utf-8"></script>
    <script src="<?php echo base_url('assets/easyui/jquery.easyui.min.js') ?>" charset="utf-8"></script>

    <script type="text/javascript">
      $.fn.combobox.defaults.width = "99%";

      var btn = [];
      var url;

      var search = {
        iconCls: 'icon-search',
        handler:function()
        {
          $('#search-dialog').dialog('setTitle','Penulis Buku - Pencarian Data').dialog('open');
          $('#sfm').form('clear');
        }
      };
      btn.push(search);

      var add = {
        text: 'Tambah Data',
        iconCls: 'icon-add',
        handler: function() {
          $('#form-dialog').dialog('setTitle','Penulis Buku - Tambah Data').dialog('open');
          $('#fm').form('clear');
          url='<?php echo site_url("Penulis/add"); ?>';
        }
      };
      btn.push(add);

      var edit = {
        text: 'Ubah Data',
        iconCls: 'icon-edit',
        handler: function() {
          var row = $('#dlg').datagrid('getSelected');
          if (!row)
          {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
          $('#form-dialog').dialog('setTitle', 'Penulis Buku - Ubah Data').dialog('open');
          $('#fm').form('load', row);
          $('#cmbJenkelPenulis').combobox('select', row.txtJenkelPenulis);
          url = '<?php echo site_url('Penulis/edit'); ?>/' + row.txtId;

        }
      };
      btn.push(edit);

      var remove = {
        text: 'Hapus Data',
        iconCls: 'icon-remove',
        handler:function()
        {
          var row = $('#dlg').datagrid('getSelected');
          if (row)
          {
            $.messager.confirm('Confirm','Yakin mau hapus record ' + row.txtNamaPenulis + '?',function(r)
            {
              if (r)
              {
                $.post('<?php echo site_url('Penulis/delete'); ?>',{id:row.txtId},function(result)
                {
                  var result = eval('('+result+')');
                  if (result.success)
                  {
                    $.messager.alert('Sukses!','Baris '+row.txtNamaPenulis+' berhasil dihapus!','info');
                    $('#dlg').datagrid('reload');
                  } else
                  {
                    $.messager.show
                    ({
                      title: 'Error',
                      msg: result.msg
                    });
                  }
                });
               }
            });
          }else
          {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
        }
      };
      btn.push(remove);

      $(function() {
        var pager = $('#dlg').datagrid('getPager');
        pager.pagination({
          buttons: btn
        });
      });

      function saveData()
      {
				$('#fm').form('submit',
        {
					url:url,
					onSubmit: function()
          {
						return $(this).form('validate');
					},
					success: function(result)
          {
						var result = eval ('('+result+')');
						if(result.success)
            {
							$('#form-dialog').dialog('close');
							$('#dlg').datagrid('reload');
						} else
            {
							$.messager.show
              ({
								title: 'Error',
								msg: result.msg
							});
						}
					}
				});
			}

			function doSearch(value,name)
      {
				if (value !="")
				{
					$('#dlg').datagrid('load',{
						findId: name,
						findNilai: value
					});
				}
			}

    </script>
  </head>
  <body>
    <table id="dlg" class="easyui-datagrid"
           style="width: auto; height: 500px;"
           url="<?php echo site_url('Penulis/getJson'); ?>"
           toolbar="#toolbar"
           footer="#footer"
           title="Data Penulis Buku"
           fit="true"
           pagination="true"
           pageSize="10" pageList="[10, 20, 30, 50]"
           stripped="true" nowrap="false"
           fitColumns="true" singleSelect="true" remoteSort="false"
           rowNumbers="true">
      <thead>
        <tr>
          <th data-options="field: 'txtId', width: 50, sortable: true, hidden: true">Kode Penulis</th>
          <th data-options="field: 'txtNamaPenulis', width: 100, sortable: true, align: 'left', halign: 'center'">Nama Penulis </th>
          <th data-options="field: 'txtAlamatPenulis', width: 100, sortable: true, align: 'left', halign: 'center'">Alamat Penulis</th>
          <th data-options="field: 'txtTempatLahirPenulis', width: 100, sortable: true, align: 'left', halign: 'center'">Tempat Lahir Penulis</th>
          <th data-options="field: 'txtTglLahirPenulis', width: 100, sortable: true, align: 'left', halign: 'center'">Tanggal Lahir Penulis</th>
          <th data-options="field: 'txtJenkelPenulis', width: 100, sortable: true, align: 'left', halign: 'center'">Jenis Kelamin Penulis</th>
          <th data-options="field: 'txtNoKontakPenulis', width: 100, sortable: true, align: 'left', halign: 'center'">No Kontak Penulis</th>
          <th data-options="field: 'txtEmailPenulis', width: 100, sortable: true, align: 'left', halign: 'center'">Email Penulis</th>
        </tr>
      </thead>
    </table>

    <div id="form-dialog" class="easyui-dialog"
         style="width: 400px; padding: 12px;"
         buttons="#dlg-btn" closed="true">
      <form id="fm" action="index.html" method="post" novalidate>
        <table width="100%" class="form-table">
          <tr>
            <td>
              <input type="hidden" name="txtId" id="txtId">
            </td>
          </tr>
          <tr>
            <td>
              <label>Nama Penulis</label>
            </td>
            <td>
              <input type="text" name="txtNamaPenulis" id="txtNamaPenulis"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Alamat Penulis</label>
            </td>
            <td>
              <input type="text" name="txtAlamatPenulis" id="txtAlamatPenulis"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Tempat Lahir Penulis</label>
            </td>
            <td>
              <input type="text" name="txtTempatLahirPenulis" id="txtTempatLahirPenulis"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Tanggal Lahir Penulis</label>
            </td>
            <td>
              <input type="text" name="txtTglLahirPenulis" id="txtTglLahirPenulis"
                     class="easyui-datebox"
                     data-options="formatter: dateFormatter, parser: dateParser" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Jenis Kelamin Penulis</label>
            </td>
            <td>
              <select class="easyui-combobox" name="cmbJenkelPenulis" id="cmbJenkelPenulis"
                      data-options="prompt: '-- PILIH --', value: ''" required>
                <option value="P">Pria</option>
                <option value="W">Wanita</option>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>No Kontak Penulis</label>
            </td>
            <td>
              <input type="text" name="txtNoKontakPenulis" id="txtNoKontakPenulis"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Email Penulis</label>
            </td>
            <td>
              <input type="text" name="txtEmailPenulis" id="txtEmailPenulis"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
        </table>
      </form>
    </div>
    <div id="dlg-btn">
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-ok" onclick="saveData()">Simpan</a>
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-cancel" onclick="javascript:$('#form-dialog').dialog('close')">Batal</a>
    </div>

    <script type="text/javascript">
      function dateFormatter(date) {
        var y = date.getFullYear();
        var m = date.getMonth()+1;
        var d = date.getDate();
        return y + '-' + (m<10?('0'+m):m) + '-' + (d<10?('0'+d):d);
      }

      function dateParser(s) {
        if (!s) return new Date();
        var ss = (s.split('-'));
        var y = parseInt(ss[0],10);
        var m = parseInt(ss[1],10);
        var d = parseInt(ss[2],10);
        if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
          return new Date(y, m-1, d);
        } else {
          return new Date();
        }
      }
    </script>

    <div id="search-dialog" class="easyui-dialog"
         style="width: 400px; height: auto; padding: 12px;"
         buttons="#src-btn" closed="true">
      <form id="sfm" action="index.html" method="post">
        <input type="text" class="easyui-searchbox"
               style="width: 100%;"
               data-options="prompt: 'Masukkan kata kunci pencarian', menu: '#mm', searcher: doSearch">

        <div id="mm">
          <div data-options="name: 'all', iconCls: 'icon-ok'">Semua</div>
          <div data-options="name: 'nama', iconCls: 'icon-ok'">Nama Penulis</div>
          <div data-options="name: 'alamat', iconCls: 'icon-ok'">Alamat Penulis</div>
          <div data-options="name: 'tempat_lahir', iconCls: 'icon-ok'">Tempat Lahir Penulis</div>
          <div data-options="name: 'tgl_lahir', iconCls: 'icon-ok'">Tanggal Lahir Penulis</div>
          <div data-options="name: 'jenkel', iconCls: 'icon-ok'">Jenis Kelamin Penulis</div>
          <div data-options="name: 'no_kontak', iconCls: 'icon-ok'">No Kontak Penulis</div>
          <div data-options="name: 'email', iconCls: 'icon-ok'">Email Penulis</div>
          </div>
      </form>
    </div>

  </body>
</html>
