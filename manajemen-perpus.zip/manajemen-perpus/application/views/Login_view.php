<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Manajemen Perpus </title>
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/default/easyui.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/icon.css') ?>">
    <script src="<?php echo base_url('assets/easyui/jquery.min.js') ?>" charset="utf-8"></script>
    <script src="<?php echo base_url('assets/easyui/jquery.easyui.min.js') ?>" charset="utf-8"></script>
  </head>
  <body class="easyui-layout">
    <div id="dialog-form" class="easyui-dialog"
         style="width: 600px; height: auto; padding: 10px 20px;"
         title="Login"
         buttons="#dlg-buttons" closed="false">
      <div class="ftitle">Login</div>
      <form id="fm" method="post" novalidate>
        <table width="100%" class="form-table">
          <tr>
            <td>
              <div id="konfirmasi"></div>
            </td>
          </tr>
          <tr>
            <td>
              <label>Username</label>
            </td>
            <td>
              <input type="text" name="user"
                     id="user" class="easyui-validatebox textbox"
                     size="50px" maxlength="50"
                     style="height: 20px;" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Password</label>
            </td>
            <td>
              <input type="password" name="password"
                     id="password" class="easyui-validatebox textbox"
                     size="50px" maxlength="50"
                     style="height: 20px;" required>
            </td>
          </tr>
        </table>
      </form>
    </div>
    <div id="dlg-buttons">
      <a href="javascript:void(0);" class="easyui-linkbutton" iconCls="icon-ok" onClick="saveData()">
        Login
      </a>
      <a href="javascript:void(0);" class="easyui-linkbutton" iconCls="icon-cancel" onclick="javascript: $('#dialog-form').dialog('close')">
        Batal
      </a>
    </div>

    <script type="text/javascript">
      var url;
      function saveData()
      {
        url = '<?php echo site_url('Login/validasi_login'); ?>';
        $('#fm').form('submit', {
          url: url,
          onSubmit: function() {
            return $(this).form('validate');
          },
          success: function(result) {
            var result = $.parseJSON(result);
            if (result.success)
            {
              $('#konfirmasi').html('<div class="alert alert-danger">'+result.msg+'</div>');
              window.location.assign('<?php echo site_url('MainPage'); ?>');
            }
            else
            {
              $('#konfirmasi').html('<div class="alert alert-danger">'+result.msg+'</div>');
            }
          }
        });
      }
    </script>
  </body>
</html>
