<div class="menu-container" title="Master Data"
     data-options="selected: true, iconCls: 'icon-search'">
  <p>
    <a href="<?php echo site_url('Genre'); ?>" target="isi">Daftar Genre Buku</a>
  </p>
  <p>
    <a href="<?php echo site_url('SubGenre'); ?>" target="isi">Daftar Sub Genre Buku</a>
  </p>
  <p>
    <a href="<?php echo site_url('Buku'); ?>" target="isi">Daftar Buku</a>
  </p>
  <p>
    <a href="<?php echo site_url('Penulis'); ?>" target="isi">Daftar Penulis Buku</a>
  </p>
  <p>
    <a href="<?php echo site_url('Penerbit'); ?>" target="isi">Daftar Penerbit Buku</a>
  </p>
  <?php if ($this->session->userdata('admin_level') == 'Admin') { ?>
    <p>
      <a href="<?php echo site_url('Staf'); ?>" target="isi">Daftar Staf </a>
    </p>
  <?php } ?>
  <p>
    <a href="<?php echo site_url('Member'); ?>" target="isi">Daftar Member</a>
  </p>
</div>
<div class="menu-container" title="Transaksi" data-options="iconCls: 'icon-large-chart'">
  <p>
    <a href="<?php echo site_url('Peminjaman'); ?>" target="isi">Peminjaman</a>
  </p>
  <p>
    <a href="<?php echo site_url('Pengembalian'); ?>" target="isi">Pengembalian</a>
  </p>
</div>

<style media="screen">
  .menu-container {
    padding: 5px 10px;
    overflow: auto;
  }
</style>
