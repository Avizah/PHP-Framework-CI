<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Pemrograman Web 2</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/default/easyui.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/icon.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
    <script src="<?php echo base_url('assets/easyui/jquery.min.js') ?>" charset="utf-8"></script>
    <script src="<?php echo base_url('assets/easyui/jquery.easyui.min.js') ?>" charset="utf-8"></script>

    <script type="text/javascript">
      $.fn.combobox.defaults.width = "99%";

      var btn = [];
      var bookbtn = [];
      var url;
      var booklist = {total: 0, rows: []};
      var tglJthTempo;
      var dialogType;

      function removeElm(array, element) {
        const index = array.map(function(e) { return e.txtBookId; }).indexOf(element)

        if (index !== -1) {
          array.splice(index, 1);
        }
      }

      var addbook = {
        iconCls: 'icon-add',
        handler: function() {
          $('#book-dialog').dialog('setTitle','Peminjaman - Tambah Buku').dialog('open');
          $('#book-fm').form('clear');
          $('#saveBookData').linkbutton('disable');
        }
      };
      bookbtn.push(addbook);

      var removebook = {
        iconCls: 'icon-remove',
        handler: function() {
          var row = $('#booklist').datagrid('getSelected');
          if (row) {
            $.messager.confirm('Confirm','Yakin mau hapus record ' + row.txtJudulBuku +'?',function(r) {
              if (r) {
                removeElm(booklist['rows'], row.txtBookId);
                booklist['total']--;
                console.log(booklist);
                $('#booklist').datagrid('loadData', booklist);
              }
            });
          } else {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
        }
      };
      bookbtn.push(removebook);

      var search = {
        iconCls: 'icon-search',
        handler:function()
        {
          $('#search-dialog').dialog('setTitle','Peminjaman - Pencarian Data').dialog('open');
          $('#sfm').form('clear');
        }
      };
      btn.push(search);

      var add = {
        text: 'Tambah Data',
        iconCls: 'icon-add',
        handler: function() {
          booklist = {total: 0, rows: []};
          $('#form-dialog').dialog('setTitle','Peminjaman - Tambah Data').dialog('open');
          $('#fm').form('clear');
          url='<?php echo site_url("Peminjaman/add"); ?>';
          dialogType = 'add';
          $('#booklist').datagrid('loadData', []);

          formEnabled(true);
        }
      };
      btn.push(add);

      var view = {
        text: 'Lihat Detail',
        iconCls: 'icon-edit',
        handler: function() {
          var row = $('#dlg').datagrid('getSelected');
          if (!row)
          {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
          $('#form-dialog').dialog('setTitle', 'Peminjaman - Detail Data').dialog('open');
          jQuery('#fm').form('load',row);
          url = '<?php echo site_url('Peminjaman/getBooklist'); ?>/' + row.txtId;
          dialogType = 'view';
          $('#booklist').datagrid('load', url);

          formEnabled(false);
        }
      };
      btn.push(view);

      var remove = {
        text: 'Hapus Data',
        iconCls: 'icon-remove',
        handler:function()
        {
          var row = $('#dlg').datagrid('getSelected');
          if (row)
          {
            $.messager.confirm('Confirm','Yakin mau hapus record transaksi ' +row.txtId+'?',function(r)
            {
              if (r)
              {
                $.post('<?php echo site_url('Peminjaman/delete'); ?>',{id:row.txtId},function(result)
                {
                  var result = eval('('+result+')');
                  if (result.success)
                  {
                    $.messager.alert('Sukses!','Transaksi '+row.txtId+' berhasil dihapus!','info');
                    $('#dlg').datagrid('reload');
                  } else
                  {
                    $.messager.show
                    ({
                      title: 'Error',
                      msg: result.msg
                    });
                  }
                });
               }
            });
          }else
          {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
        }
      };
      btn.push(remove);

      var report = {
        text: 'Cetak Laporan',
        iconCls: 'icon-print',
        handler: function() {
          $('#report-dialog').dialog('open');
        }
      };
      btn.push(report);

      $(function() {
        var pager = $('#dlg').datagrid('getPager');
        pager.pagination({
          buttons: btn
        });
      });

      function formEnabled(isEnabled) {
        // Enable/disable datagrid buttons
        var pager = $('#booklist').datagrid('getPager');
        pager.pagination({
          buttons: (isEnabled) ? bookbtn : []
        });

        // Enable/disable form component
        $('#txtTglPeminjaman').datebox('readonly', !isEnabled);
        $('#cmbMember').combobox('readonly', !isEnabled);
        $('#cmbStaf').combobox('readonly', !isEnabled);
      }
    </script>
  </head>
  <body>
    <table id="dlg" class="easyui-datagrid"
           style="width: auto; height: 500px;"
           url="<?php echo site_url('Peminjaman/getJson'); ?>"
           toolbar="#toolbar"
           footer="#footer"
           title="Data Peminjaman "
           fit="true"
           pagination="true"
           pageSize="10" pageList="[10, 20, 30, 50]"
           stripped="true" nowrap="false"
           fitColumns="true" singleSelect="true" remoteSort="false"
           rowNumbers="true">
      <thead>
        <tr>
          <th data-options="field: 'cmbMember', width: 50, sortable: true, hidden: true">KD Member Peminjaman</th>
          <th data-options="field: 'cmbStaf', width: 100, sortable: true, hidden: true">KD Staf</th>
          <th data-options="field: 'txtId', width: 100, sortable: true, align: 'left', halign: 'center'">Kode Transaksi</th>
          <th data-options="field: 'txtTglPeminjaman', width: 100, sortable: true, align: 'left', halign: 'center'">Tanggal Peminjaman</th>
          <th data-options="field: 'txtTglJatuhTempo', width: 100, sortable: true, align: 'left', halign: 'center'">Tanggal Jatuh Tempo</th>
          <th data-options="field: 'txtNamaMember', width: 100, sortable: true, align: 'left', halign: 'center'">Nama Member</th>
          <th data-options="field: 'txtNamaStaf', width: 100, sortable: true, align: 'left', halign: 'center'">Nama Staf</th>
        </tr>
      </thead>
    </table>

    <div id="form-dialog" class="easyui-dialog"
         style="width: 600px; padding: 12px;"
         buttons="#dlg-btn" closed="true">
      <form id="fm" action="index.html" method="post" novalidate>
        <table width="100%" class="form-table">
          <tr>
            <td>
              <input type="hidden" name="data" id="data">
            </td>
            <td>
              <input type="hidden" name="txtId" id="txtId">
            </td>
          </tr>
          <tr>
            <td>
              <label>Tanggal Peminjaman</label>
            </td>
            <td>
              <input type="text" name="txtTglPeminjaman" id="txtTglPeminjaman"
                     class="easyui-datebox"
                     data-options="formatter: dateFormatter, parser: dateParser" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Peminjam</label>
            </td>
            <td>
              <select class="easyui-combobox" name="cmbMember" id="cmbMember"
                      data-options="prompt: '-- PILIH --', value: ''" required>
                <?php
                  foreach ($daftarPeminjam as $peminjam) {
                    echo "<option value='$peminjam[id_member]'>$peminjam[nama]</option>";
                  }
                ?>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>Staf</label>
            </td>
            <td>
              <select class="easyui-combobox" name="cmbStaf" id="cmbStaf"
                      data-options="prompt: '-- PILIH --', value: ''" required>
                      <?php
                        foreach ($daftarStaf as $staf) {
                          echo "<option value='$staf[id_staf]'>$staf[nama]</option>";
                        }
                      ?>
              </select>
            </td>
          </tr>
        </table>
        <label>Daftar Buku Pinjaman</label>
        <table id="booklist" class="easyui-datagrid"
               style="width: 100%; height: 200px;"
               pagination="true"
               pageSize="10" pageList="[10, 20, 30, 50]"
               stripped="true" nowrap="false"
               fitColumns="true" singleSelect="true" remoteSort="false"
               rowNumbers="true">
          <thead>
            <tr>
              <th data-options="field: 'txtBookId', width: 50, sortable: true, hidden: true">ID</th>
              <th data-options="field: 'txtJudulBuku', width: 100, sortable: true, align: 'left', halign: 'center'">Judul Buku</th>
              <th data-options="field: 'txtEdisi', width: 100, sortable: true, align: 'left', halign: 'center'">Edisi</th>
              <th data-options="field: 'txtNamaPenulis', width: 100, sortable: true, align: 'left', halign: 'center'">Penulis</th>
            </tr>
          </thead>
        </table>
      </form>
    </div>
    <div id="dlg-btn">
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-ok" onclick="saveData(dialogType)">Simpan</a>
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-cancel" onclick="javascript:$('#form-dialog').dialog('close')">Batal</a>
    </div>

    <div id="book-dialog" class="easyui-dialog"
         style="width: 400px; padding: 12px;"
         buttons="#dlg-btn2" closed="true">
      <form id="book-fm" action="index.html" method="post">
        <table class="form-table">
          <tr>
            <td>
              <input type="hidden" name="txtBookId" id="txtBookId">
            </td>
          </tr>
          <tr>
            <td>
              <label>ISBN</label>
            </td>
            <td>
              <input type="text" name="txtIsbn" id="txtIsbn"
                     class="easyui-validatebox textbox"
                     maxlength="13" required>
            </td>
            <td>
              <a href="javascript:void(0);" class="easyui-linkbutton"
                 iconCls="icon-reload" onclick="getBook()"></a>
            </td>
          </tr>
          <tr style="height: 8px;">
            <td></td>
          </tr>
          <tr>
            <td>
              <label>Judul Buku</label>
            </td>
            <td colspan="2">
              <input type="text" name="txtJudulBuku" id="txtJudulBuku"
                     class="easyui-validatebox textbox" data-options="readonly: true">
            </td>
          </tr>
          <tr>
            <td>
              <label>Edisi</label>
            </td>
            <td colspan="2">
              <input type="text" name="txtEdisi" id="txtEdisi"
                     class="easyui-validatebox textbox" data-options="readonly: true">
            </td>
          </tr>
          <tr>
            <td>
              <label>Penulis</label>
            </td>
            <td colspan="2">
              <input type="text" name="txtNamaPenulis" id="txtNamaPenulis"
                     class="easyui-validatebox textbox" data-options="readonly: true">
            </td>
          </tr>
          <tr>
            <td>
              <label>Penerbit</label>
            </td>
            <td colspan="2">
              <input type="text" name="txtNamaPenerbit" id="txtNamaPenerbit"
                     class="easyui-validatebox textbox" data-options="readonly: true">
            </td>
          </tr>
          <tr>
            <td>
              <label>Tahun Terbit</label>
            </td>
            <td colspan="2">
              <input type="text" name="txtThnTerbit" id="txtThnTerbit"
                     class="easyui-validatebox textbox" data-options="readonly: true">
            </td>
          </tr>
          <tr>
            <td>
              <label>Genre Buku</label>
            </td>
            <td colspan="2">
              <input type="text" name="txtNamaGenre" id="txtNamaGenre"
                     class="easyui-validatebox textbox" data-options="readonly: true">
            </td>
          </tr>
          <tr>
            <td style="width: 1%; white-space: nowrap;">
              <label>Sub Genre Buku</label>
            </td>
            <td colspan="2">
              <input type="text" name="txtNamaSubGenre" id="txtNamaSubGenre"
                     class="easyui-validatebox textbox" data-options="readonly: true">
            </td>
          </tr>
          <tr>
            <td>
              <label>Stok</label>
            </td>
            <td colspan="2">
              <input type="text" name="txtStok" id="txtStok"
                     class="easyui-validatebox textbox" data-options="readonly: true">
            </td>
          </tr>
        </table>
      </form>
    </div>
    <div id="dlg-btn2">
      <a id="saveBookData" href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-ok" onclick="saveData('book')">Simpan</a>
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-cancel" onclick="javascript:$('#book-dialog').dialog('close')">Batal</a>
    </div>

    <div id="search-dialog" class="easyui-dialog"
         style="width: 400px; height: auto; padding: 12px;"
         buttons="#src-btn" closed="true">
      <form id="sfm" action="index.html" method="post">
        <input type="text" class="easyui-searchbox"
               style="width: 100%;"
               data-options="prompt: 'Masukkan kata kunci pencarian', menu: '#mm', searcher: doSearch">

        <div id="mm">
          <div data-options="name: 'all', iconCls: 'icon-ok'">Semua</div>
          <div data-options="name: 'kd_transaksi', iconCls: 'icon-ok'">KD Transaksi Peminjaman</div>
          <div data-options="name: 'nama_member', iconCls: 'icon-ok'">Nama Member</div>
          <div data-options="name: 'nama_staf', iconCls: 'icon-ok'">Nama Staf</div>
        </div>
      </form>
    </div>

    <div id="report-dialog" class="easyui-dialog"
         title="Laporan Transaksi Peminjaman"
         style="width: 400px; padding: 12px;"
         buttons="#report-buttons" closed="true">
      <form id="rfm" name="rfm" method="post">
        <table width="100%" class="form-table">
          <tr>
            <td>
              <label>Tipe Laporan</label>
            </td>
            <td>
              <select class="easyui-combobox" name="cmbFileType" id="cmbFileType"
                      data-options="prompt: '-- PILIH --', value: 'pdf'" required>
                <option value="pdf">PDF</option>
                <option value="excel">Excel</option>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>Dari Tanggal</label>
            </td>
            <td>
              <input type="text" name="txtTglAwal" id="txtTglAwal"
                     class="easyui-datebox"
                     data-options="formatter: dateFormatter, parser: dateParser" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Sampai Tanggal</label>
            </td>
            <td>
              <input type="text" name="txtTglAkhir" id="txtTglAkhir"
                     class="easyui-datebox"
                     data-options="formatter: dateFormatter, parser: dateParser" required>
            </td>
          </tr>
        </table>
      </form>
    </div>

    <div id="report-buttons">
      <a class="easyui-linkbutton" iconCls="icon-ok"
         href="javascript:void(0);" onclick="prosesReport()">Ok</a>
      <a class="easyui-linkbutton" iconCls="icon-cancel"
         href="javascript:void(0);" onclick="javascript: $('#report-dialog').dialog('close')">Tutup</a>
    </div>

    <script type="text/javascript">
      function saveData(type)
      {
        if (type == 'add') {
          var params = {booklist: booklist['rows'], tglJthTempo: tglJthTempo}
          var str = JSON.stringify(params);
          $('#data').val(str);
          $('#fm').form('submit', {
            url: url,
            onSubmit: function()
            {
              return $(this).form('validate');
            },
            success: function(result)
            {
              var result = eval ('('+result+')');
              if(result.success) {
                $('#form-dialog').dialog('close');
                $('#dlg').datagrid('reload');
              }
              else {
                $.messager.show
                ({
                  title: 'Error',
                  msg: result.msg
                });
              }
            }
          });
        } else if (type == 'view') {
          $('#form-dialog').dialog('close');
        } else if (type == 'book') {
          booklist['total']++;
          booklist['rows'].push({
            txtBookId: $('#txtBookId').val(),
            txtJudulBuku: $('#txtJudulBuku').val(),
            txtEdisi: $('#txtEdisi').val(),
            txtNamaPenulis: $('#txtNamaPenulis').val()
          });
          $('#book-dialog').dialog('close');
          $('#booklist').datagrid('loadData', booklist);
        }
      }

      function doSearch (value,name)
      {
        if (value !="")
        {
          $('#dlg').datagrid('load',{
            findId: name,
            findNilai: value
          });
        }
      }

      function dateFormatter(date) {
        var y = date.getFullYear();
        var m = date.getMonth()+1;
        var d = date.getDate();
        return y + '-' + (m<10?('0'+m):m) + '-' + (d<10?('0'+d):d);
      }

      function dateParser(s) {
        if (!s) return new Date();
        var ss = (s.split('-'));
        var y = parseInt(ss[0],10);
        var m = parseInt(ss[1],10);
        var d = parseInt(ss[2],10);
        if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
          return new Date(y, m-1, d);
        } else {
          return new Date();
        }
      }

      function getBook() {
        $('#book-fm').form('submit', {
          url: '<?php echo site_url("Peminjaman/getBook"); ?>',
          onSubmit: function() {
            return $(this).form('validate');
          },
          success: function(result) {
            var result = eval('('+result+')');
            if (result['success']) {
              for (i in result) {
                $('input[name = "' + i + '"]').val(result[i]);
              }
              $('#saveBookData').linkbutton('enable');
            } else {
              $('#saveBookData').linkbutton('disable');
              $('#book-fm').form('clear');
              $.messager.show({
                title: 'Error',
                msg: result.msg
              });
            }
          }
        });
      }

      $('#txtTglPeminjaman').datebox({
        onSelect: function(date){
          var newDate = new Date(date);
          newDate.setDate(newDate.getDate() + 14);
          var y = newDate.getFullYear();
          var m = newDate.getMonth()+1;
          var d = newDate.getDate();
          tglJthTempo = y + '-' + (m<10?('0'+m):m) + '-' + (d<10?('0'+d):d);
        }
      });

      function prosesReport() {
        url = '<?php echo site_url("Peminjaman/export"); ?>';
        $('#rfm').form('submit', {
          url: url,
          onSubmit: function() {
            $('#report-dialog').dialog('close');
            return $(this).form('validate');
          }
        });
      }
    </script>
  </body>
</html>
