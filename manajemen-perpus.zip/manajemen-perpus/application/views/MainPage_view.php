<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Pemrograman Web 2</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/default/easyui.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/icon.css') ?>">
    <script src="<?php echo base_url('assets/easyui/jquery.min.js') ?>" charset="utf-8"></script>
    <script src="<?php echo base_url('assets/easyui/jquery.easyui.min.js') ?>" charset="utf-8"></script>
  </head>
  <body class="easyui-layout">
    <!-- TOP Layout -->
    <div data-options="region: 'north', split: false"
         style="height: 90px; padding: 20px; background-color: #e4ecff;">
      <span style="font-size: 30px;">Manajemen Perpus</span>

      <span style="float: right; font-size: 30px;">
        Pustaka Indo <br>
        <span style="float: right; font-size: 14px;">
          User: <?php echo $this->session->userdata('admin_nama'); ?>
          | <a href="<?php echo site_url('MainPage/logout'); ?>" onclick="return confirm('Keluar..?')">Logout</a>
        </span>
      </span>
    </div>

    <!-- LEFT -->
    <div data-options="region: 'west', split: true"
         title="Main Menu"
         style="width: 200px; padding: 1px; overflow: hidden;">
      <div class="easyui-accordion"
           data-options="fit: true, border: false">
        <?php $this->load->view('menu'); ?>
      </div>
    </div>

    <!-- BOTTOM -->
    <div data-options="region: 'south'"
         style="text-align: right; height: 45px; background-color: #e4ecff; padding: 0px;">
      <p>
        <font color="#0142fe">
          <strong>Copyright &copy; 2018 by FASILKOM</strong>
        </font>&nbsp;&nbsp;&nbsp;
      </p>
    </div>

    <!-- CENTER -->
    <div data-options="region: 'center'"
         style="padding: 1px;">
      <iframe width="100%" height="99%"
              style="background-color: #e4ecff;"
              frameborder="0"
              name="isi"></iframe>
    </div>
  </body>
</html>
