<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Pemrograman Web 2</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/default/easyui.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/icon.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
    <script src="<?php echo base_url('assets/easyui/jquery.min.js') ?>" charset="utf-8"></script>
    <script src="<?php echo base_url('assets/easyui/jquery.easyui.min.js') ?>" charset="utf-8"></script>
    <script type="text/javascript">
      $.fn.combobox.defaults.width = "99%";

      var url;
      var btn = [];

      var search = {
      iconCls: 'icon-search',
      handler: function() {
          $('#search-dialog').dialog('setTitle', 'Buku - Pencarian Data').dialog('open');
          $('#sfm').form('clear');
        }
      };
      btn.push(search);

      var add = {
      text: 'Tambah Data',
      iconCls: 'icon-add',
      handler: function() {
          $('#form-dialog').dialog('setTitle', 'Buku - Tambah Data').dialog('open');
          $('#fm').form('clear');
          url = '<?php echo site_url("Buku/add"); ?>'
        }
      };
      btn.push(add);

      var edit = {
        text: 'Ubah Data',
        iconCls: 'icon-edit',
        handler: function() {
          var row = $('#dlg').datagrid('getSelected');
          if (!row)
          {
            $.messager.alert('Warning', 'Tidak ada baris yang terpilih!', 'error');
            exit();
          }

          $('#form-dialog').dialog('setTitle', 'Buku - Ubah Data').dialog('open');
          $('#fm').form('load', row);
          url = '<?php echo site_url("Buku/edit"); ?>/' + row.txtId;
        }
      };
      btn.push(edit);

      var remove = {
        text: 'Hapus Data',
        iconCls: 'icon-remove',
        handler: function() {
          var row = $('#dlg').datagrid('getSelected');

          if (row)
          {
            $.messager.confirm('Confirm', 'Yakin mau hapus record buku ' + row.txtJudulBuku + '?', function(r) {
              if (r)
              {
                $.post('<?php echo site_url('Buku/delete'); ?>', {id: row.txtId}, function(result) {
                  var result = eval('('+ result +')');
                  if (result.success)
                  {
                    $.messager.alert('Sukses!', 'Baris ' + row.txtJudulBuku + ' berhasil dihapus!', 'info');
                    $('#dlg').datagrid('reload');
                  }
                  else
                  {
                    $.messager.show({
                      title: 'ERROR',
                      msg: result.msg
                    });
                  }
                });
              }
            });
          }
          else
          {
            $.messager.alert('Warning', 'Tidak ada baris yang terpilih!', 'error');
            exit();
          }
        }
      };
      btn.push(remove);

      $(function() {
        var pager = $('#dlg').datagrid('getPager');
        pager.pagination({ buttons: btn });
      });
    </script>
  </head>
  <body>
    <table id="dlg" class="easyui-datagrid"
           style="width: auto; height: 500px"
           url="<?php echo site_url('Buku/getJson'); ?>"
           toolbar="#toolbar"
           footer="#footer"
           title="Data Buku"
           fit="true"
           pagination="true"
           pageSize="10" pageList="[10, 20, 30, 50]"
           stripped="true" nowrap="false"
           fitColumns="true" singleSelect="true" remoteSort="false"
           rowNumbers="true">
      <thead>
        <tr>
          <th data-options="field: 'txtId', width: 50, sortable: true, hidden: true">ID</th>
          <th data-options="field: 'cmbPenulis', width: 50, sortable: true, hidden: true">KD PENULIS</th>
          <th data-options="field: 'cmbPenerbit', width: 50, sortable: true, hidden: true">KD PENERBIT</th>
          <th data-options="field: 'cmbGenre', width: 50, sortable: true, hidden: true">KD GENRE</th>
          <th data-options="field: 'cmbSubGenre', width: 50, sortable: true, hidden: true">KD SUB GENRE</th>
          <th data-options="field: 'txtIsbn', width: 100, sortable: true, align: 'left', halign: 'center'">ISBN</th>
          <th data-options="field: 'txtJudulBuku', width: 100, sortable: true, align: 'left', halign: 'center'">Judul Buku</th>
          <th data-options="field: 'txtEdisi', width: 100, sortable: true, align: 'left', halign: 'center'">Edisi</th>
          <th data-options="field: 'txtNamaPenulis', width: 100, sortable: true, align: 'left', halign: 'center'">Penulis</th>
          <th data-options="field: 'txtNamaPenerbit', width: 100, sortable: true, align: 'left', halign: 'center'">Penerbit</th>
          <th data-options="field: 'txtThnTerbit', width: 100, sortable: true, align: 'left', halign: 'center'">Tahun Terbit</th>
          <th data-options="field: 'txtNamaGenre', width: 100, sortable: true, align: 'left', halign: 'center'">Genre</th>
          <th data-options="field: 'txtNamaSubGenre', width: 100, sortable: true, align: 'left', halign: 'center'">Sub Genre</th>
          <th data-options="field: 'txtStok', width: 100, sortable: true, align: 'center', halign: 'center'">Stok</th>
        </tr>
      </thead>
    </table>

    <div id="form-dialog" class="easyui-dialog"
         style="width: 400px; padding: 12px;"
         buttons="#dlg-btn" closed="true">
      <form id="fm" action="index.html" method="post">
        <table class="form-table">
          <tr>
            <td>
              <input type="hidden" name="txtId" id="txtId">
            </td>
          </tr>
          <tr>
            <td>
              <label>ISBN</label>
            </td>
            <td>
              <input type="text" name="txtIsbn" id="txtIsbn"
                     class="easyui-validatebox textbox"
                     maxlength="13" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Judul Buku</label>
            </td>
            <td>
              <input type="text" name="txtJudulBuku" id="txtJudulBuku"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Edisi</label>
            </td>
            <td>
              <input type="text" name="txtEdisi" id="txtEdisi"
                     class="easyui-validatebox textbox"
                     maxlength="3" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Penulis</label>
            </td>
            <td>
              <select class="easyui-combobox" name="cmbPenulis" id="cmbPenulis"
                      data-options="prompt: '-- PILIH --', value: ''" required>
                <?php
                  foreach ($daftarPenulis as $penulis) {
                    echo "<option value='$penulis[kd_penulis]'>$penulis[nama]</option>";
                  }
                ?>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>Penerbit</label>
            </td>
            <td>
              <select class="easyui-combobox" name="cmbPenerbit" id="cmbPenerbit"
                      data-options="prompt: '-- PILIH --', value: ''" required>
                <?php
                  foreach ($daftarPenerbit as $penerbit) {
                    echo "<option value='$penerbit[kd_penerbit]'>$penerbit[nama]</option>";
                  }
                ?>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>Tahun Terbit</label>
            </td>
            <td>
              <input type="text" name="txtThnTerbit" id="txtThnTerbit"
                     class="easyui-validatebox textbox"
                     maxlength="4" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Genre Buku</label>
            </td>
            <td>
              <select class="easyui-combobox" name="cmbGenre" id="cmbGenre"
                      data-options="prompt: '-- PILIH --', value: ''" required>
                <?php
                  foreach ($daftarGenre as $genre) {
                    echo "<option value='$genre[kd_genre]'>$genre[nama_genre]</option>";
                  }
                ?>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>Sub Genre Buku</label>
            </td>
            <td>
              <select class="easyui-combobox" name="cmbSubGenre" id="cmbSubGenre"
                      data-options="prompt: '-- PILIH --', value: ''" required>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>Stok</label>
            </td>
            <td>
              <input type="text" name="txtStok" id="txtStok"
                     class="easyui-validatebox textbox"
                     maxlength="3" required>
            </td>
          </tr>
        </table>
      </form>
    </div>
    <div id="dlg-btn">
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-ok" onclick="saveData()">Simpan</a>
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-cancel" onclick="javascript: $('#form-dialog').dialog('close');">Batal</a>
    </div>

    <div id="search-dialog" class="easyui-dialog"
         style="width: 400px; height: auto; padding: 12px;"
         buttons="#src-btn" closed="true">
      <form id="sfm" action="index.html" method="post">
        <input type="text" class="easyui-searchbox"
               style="width: 100%;"
               data-options="prompt: 'Masukkan kata kunci pencarian', menu: '#mm', searcher: doSearch">

        <div id="mm">
          <div data-options="name: 'all', iconCls: 'icon-ok'">Semua</div>
          <div data-options="name: 'isbn', iconCls: 'icon-ok'">ISBN</div>
          <div data-options="name: 'judul', iconCls: 'icon-ok'">Judul Buku</div>
          <div data-options="name: 'nama_penulis', iconCls: 'icon-ok'">Penulis</div>
          <div data-options="name: 'nama_penerbit', iconCls: 'icon-ok'">Penerbit</div>
          <div data-options="name: 'tahun_terbit', iconCls: 'icon-ok'">Tahun Terbit</div>
          <div data-options="name: 'nama_genre', iconCls: 'icon-ok'">Genre</div>
          <div data-options="name: 'nama_subgenre', iconCls: 'icon-ok'">Sub Genre</div>
        </div>
      </form>
    </div>

    <script type="text/javascript">
      function saveData() {
        $('#fm').form('submit', {
          url: url,
          onSubmit: function() {
            return $(this).form('validate');
          },
          success: function(result) {
            var result = eval('('+result+')');
            if (result.success) {
              $('#form-dialog').dialog('close');
              $('#dlg').datagrid('reload');
            } else {
              $.messager.show({
                title: 'Error',
                msg: result.msg
              });
            }
          }
        });
      }

      function doSearch(value, name) {
        if (value != "") {
          $('#dlg').datagrid('load', {
            findId: name,
            findNilai: value
          });
        }
      }

      $('#cmbGenre').combobox({
        onSelect: function(record) {
          var url = '<?php echo site_url("Buku/getSubGenre"); ?>/' + record.value;
          $('#cmbSubGenre').combobox('clear').combobox('reload', url);
        }
      });
    </script>
  </body>
</html>
