<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Pemrograman Web 2</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/default/easyui.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/icon.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
    <script src="<?php echo base_url('assets/easyui/jquery.min.js') ?>" charset="utf-8"></script>
    <script src="<?php echo base_url('assets/easyui/jquery.easyui.min.js') ?>" charset="utf-8"></script>

    <script type="text/javascript">
      $.fn.combobox.defaults.width = "99%";
      $.extend($.fn.validatebox.defaults.rules, {
        phoneNumber: {
          validator: function(value, param) {
            return (value.length >= 10 && value.length <= 12 && value.match(/\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/));
          },
          message: 'Please enter a valid phone number'
        }
      });

      var btn = [];
      var url;

      var search = {
        iconCls: 'icon-search',
        handler:function()
        {
          $('#search-dialog').dialog('setTitle','Staf - Pencarian Data').dialog('open');
          $('#sfm').form('clear');
        }
      };
      btn.push(search);

      var add = {
        text: 'Tambah Data',
        iconCls: 'icon-add',
        handler: function() {
          $('#form-dialog').dialog('setTitle','Staf - Tambah Data').dialog('open');
          $('#fm').form('clear');
          url='<?php echo site_url("Staf/add"); ?>';
        }
      };
      btn.push(add);

      var edit = {
        text: 'Ubah Data',
        iconCls: 'icon-edit',
        handler: function() {
          var row = $('#dlg').datagrid('getSelected');
          if (!row)
          {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
          $('#form-dialog').dialog('setTitle', 'Staf - Ubah Data').dialog('open');
          jQuery('#fm').form('load',row);
          var passwordLama = $('#txtPasswordStaf').val();
          $('#txtPasswordLama').val(passwordLama);
          url = '<?php echo site_url('Staf/edit'); ?>/' + row.txtId;

        }
      };
      btn.push(edit);

      var remove = {
        text: 'Hapus Data',
        iconCls: 'icon-remove',
        handler:function()
        {
          var row = $('#dlg').datagrid('getSelected');
          if (row)
          {
            $.messager.confirm('Confirm','Yakin mau hapus record ' +row.txtNamaStaf+'?',function(r)
            {
              if (r)
              {
                $.post('<?php echo site_url('Staf/delete'); ?>',{id:row.txtId},function(result)
                {
                  var result = eval('('+result+')');
                  if (result.success)
                  {
                    $.messager.alert('Sukses!','Baris '+row.txtNamaStaf+' berhasil dihapus!','info');
                    $('#dlg').datagrid('reload');
                  } else
                  {
                    $.messager.show
                    ({
                      title: 'Error',
                      msg: result.msg
                    });
                  }
                });
               }
            });
          }else
          {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
        }
      };
      btn.push(remove);

      $(function() {
        var pager = $('#dlg').datagrid('getPager');
        pager.pagination({
          buttons: btn
        });
      });
    </script>
  </head>
  <body>
    <table id="dlg" class="easyui-datagrid"
           style="width: auto; height: 500px;"
           url="<?php echo site_url('Staf/getJson'); ?>"
           toolbar="#toolbar"
           footer="#footer"
           title="Data Staf "
           fit="true"
           pagination="true"
           pageSize="10" pageList="[10, 20, 30, 50]"
           stripped="true" nowrap="false"
           fitColumns="true" singleSelect="true" remoteSort="false"
           rowNumbers="true">
      <thead>
        <tr>
          <th data-options="field: 'txtId', width: 50, sortable: true, hidden: true">ID</th>
          <th data-options="field: 'txtNamaStaf', width: 100, sortable: true, align: 'left', halign: 'center'">Nama</th>
          <th data-options="field: 'txtAlamatStaf', width: 100, sortable: true, align: 'left', halign: 'center'">Alamat</th>
          <th data-options="field: 'txtTempatLahirStaf', width: 100, sortable: true, align: 'left', halign: 'center'">Tempat Lahir</th>
          <th data-options="field: 'txtTglLahirStaf', width: 100, sortable: true, align: 'left', halign: 'center'">Tanggal Lahir</th>
          <th data-options="field: 'cmbJenkelStaf', width: 100, sortable: true, align: 'left', halign: 'center'">Jenis Kelamin</th>
          <th data-options="field: 'txtNoKontakStaf', width: 100, sortable: true, align: 'left', halign: 'center'">No Kontak</th>
          <th data-options="field: 'txtEmailStaf', width: 100, sortable: true, align: 'left', halign: 'center'">Email</th>
          <th data-options="field: 'cmbLevelStaf', width: 100, sortable: true, align: 'left', halign: 'center'">Level </th>
          <th data-options="field: 'txtUserStaf', width: 100, sortable: true, align: 'left', halign: 'center'">User</th>
          <th data-options="field: 'txtPasswordStaf', width: 100, sortable: true, align: 'left', halign: 'center'">Password</th>
        </tr>
      </thead>
    </table>

    <div id="form-dialog" class="easyui-dialog"
         style="width: 400px; padding: 12px;"
         buttons="#dlg-btn" closed="true">
      <form id="fm" action="index.html" method="post" novalidate>
        <table width="100%" class="form-table">
          <tr>
            <td>
              <input type="hidden" name="txtId" id="txtId">
            </td>
            <td>
              <input type="hidden" name="txtPasswordLama" id="txtPasswordLama">
            </td>
          </tr>
          <tr>
            <td>
              <label>Nama</label>
            </td>
            <td>
              <input type="text" name="txtNamaStaf" id="txtNamaStaf"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Alamat</label>
            </td>
            <td>
              <input type="text" name="txtAlamatStaf" id="txtAlamatStaf"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Tempat Lahir</label>
            </td>
            <td>
              <input type="text" name="txtTempatLahirStaf" id="txtTempatLahirStaf"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Tanggal Lahir</label>
            </td>
            <td>
              <input type="text" name="txtTglLahirStaf" id="txtTglLahirStaf"
                     class="easyui-datebox"
                     data-options="formatter: dateFormatter, parser: dateParser" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Jenis Kelamin</label>
            </td>
            <td>
              <select class="easyui-combobox" name="cmbJenkelStaf" id="cmbJenkelStaf"
                      data-options="prompt: '-- PILIH --', value: ''" required>
                <option value="Pria">Pria</option>
                <option value="Wanita">Wanita</option>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>No Kontak</label>
            </td>
            <td>
              <input type="text" name="txtNoKontakStaf" id="txtNoKontakStaf"
                     class="easyui-validatebox textbox"
                     validType="phoneNumber" maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Email</label>
            </td>
            <td>
              <input type="text" name="txtEmailStaf" id="txtEmailStaf"
                     class="easyui-validatebox textbox"
                     validType="email" maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Level Staf</label>
            </td>
            <td>
              <select class="easyui-combobox" name="cmbLevelStaf" id="cmbLevelStaf"
                      data-options="prompt: '-- PILIH --', value: ''" required>
                <option value="Admin">Admin</option>
                <option value="Pegawai">Pegawai</option>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>Username</label>
            </td>
            <td>
              <input type="text" name="txtUserStaf" id="txtUserStaf"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Password</label>
            </td>
            <td>
              <input type="password" name="txtPasswordStaf" id="txtPasswordStaf"
                     class="easyui-validatebox textbox"
                     maxlength="300" required>
            </td>
          </tr>

        </table>
      </form>
    </div>
    <div id="dlg-btn">
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-ok" onclick="saveData()">Simpan</a>
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-cancel" onclick="javascript: $('#form-dialog').dialog('close')">Batal</a>
    </div>

    <div id="search-dialog" class="easyui-dialog"
         style="width: 400px; height: auto; padding: 12px;"
         buttons="#src-btn" closed="true">
      <form id="sfm" action="index.html" method="post">
        <input type="text" class="easyui-searchbox"
               style="width: 100%;"
               data-options="prompt: 'Masukkan kata kunci pencarian', menu: '#mm', searcher: doSearch">

        <div id="mm">
          <div data-options="name: 'all', iconCls: 'icon-ok'">Semua</div>
          <div data-options="name: 'nama', iconCls: 'icon-ok'">Nama Staf</div>
          <div data-options="name: 'alamat', iconCls: 'icon-ok'">Alamat Staf</div>
          <div data-options="name: 'tempat_lahir', iconCls: 'icon-ok'">Tempat Lahir Staf</div>
          <div data-options="name: 'tgl_lahir', iconCls: 'icon-ok'">Tanggal Lahir Staf</div>
          <div data-options="name: 'jenkel', iconCls: 'icon-ok'">Jenis Kelamin Staf</div>
          <div data-options="name: 'no_kontak', iconCls: 'icon-ok'">No Kontak Staf</div>
          <div data-options="name: 'email', iconCls: 'icon-ok'">Email Staf</div>
          <div data-options="name: 'user', iconCls: 'icon-ok'">User Staf</div>
          <div data-options="name: 'password', iconCls: 'icon-ok'">Password Staf</div>
        </div>
      </form>
    </div>

    <script type="text/javascript">
      function saveData()
      {
        $('#fm').form('submit',
        {
          url:url,
          onSubmit: function()
          {
            return $(this).form('validate');
          },
          success: function(result)
          {
            var result = eval ('('+result+')');
            if(result.success)
            {
              $('#form-dialog').dialog('close');
              $('#dlg').datagrid('reload');
            } else
            {
              $.messager.show
              ({
                title: 'Error',
                msg: result.msg
              });
            }
          }
        });
      }

      function doSearch (value,name)
      {
        if (value !="")
        {
          $('#dlg').datagrid('load',{
            findId: name,
            findNilai: value
          });
        }
      }

      function dateFormatter(date) {
        var y = date.getFullYear();
        var m = date.getMonth()+1;
        var d = date.getDate();
        return y + '-' + (m<10?('0'+m):m) + '-' + (d<10?('0'+d):d);
      }

      function dateParser(s) {
        if (!s) return new Date();
        var ss = (s.split('-'));
        var y = parseInt(ss[0],10);
        var m = parseInt(ss[1],10);
        var d = parseInt(ss[2],10);
        if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
          return new Date(y, m-1, d);
        } else {
          return new Date();
        }
      }
    </script>
  </body>
</html>
