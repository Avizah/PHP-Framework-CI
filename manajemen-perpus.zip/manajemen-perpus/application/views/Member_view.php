<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Pemrograman Web 2</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/default/easyui.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/easyui/themes/icon.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
    <script src="<?php echo base_url('assets/easyui/jquery.min.js') ?>" charset="utf-8"></script>
    <script src="<?php echo base_url('assets/easyui/jquery.easyui.min.js') ?>" charset="utf-8"></script>

    <script type="text/javascript">
      $.fn.combobox.defaults.width = "99%";

      var btn = [];
      var url;

      var search = {
        iconCls: 'icon-search',
        handler:function()
        {
          $('#search-dialog').dialog('setTitle','Member - Pencarian Data').dialog('open');
          $('#sfm').form('clear');
        }
      };
      btn.push(search);

      var add = {
        text: 'Tambah Data',
        iconCls: 'icon-add',
        handler: function() {
          $('#form-dialog').dialog('setTitle','Member - Tambah Data').dialog('open');
          $('#fm').form('clear');
          url='<?php echo site_url("Member/add"); ?>';
        }
      };
      btn.push(add);

      var edit = {
        text: 'Ubah Data',
        iconCls: 'icon-edit',
        handler: function() {
          var row = jQuery('#dlg').datagrid('getSelected');
          if (!row)
          {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
          $('#form-dialog').dialog('setTitle', 'Member - Ubah Data').dialog('open');
          jQuery('#fm').form('load',row);
          url = '<?php echo site_url('Member/edit'); ?>/' + row.txtId;

        }
      };
      btn.push(edit);

      var remove = {
        text: 'Hapus Data',
        iconCls: 'icon-remove',
        handler:function()
        {
          var row = $('#dlg').datagrid('getSelected');
          if (row)
          {
            $.messager.confirm('Confirm','Yakin mau hapus record ' +row.txtNamaMember+'?',function(r)
            {
              if (r)
              {
                $.post('<?php echo site_url('Member/delete'); ?>',{id:row.txtId},function(result)
                {
                  var result = eval('('+result+')');
                  if (result.success)
                  {
                    $.messager.alert('Sukses!','Baris '+row.txtNamaMember+' berhasil dihapus!','info');
                    $('#dlg').datagrid('reload');
                  } else
                  {
                    $.messager.show
                    ({
                      title: 'Error',
                      msg: result.msg
                    });
                  }
                });
               }
            });
          }else
          {
            $.messager.alert('Warning','Tidak ada baris yang terpilih!','error');
            exit();
          }
        }
      };
      btn.push(remove);

      $(function() {
        var pager = $('#dlg').datagrid('getPager');
        pager.pagination({
          buttons: btn
        });
      });
    </script>
  </head>
  <body>
    <table id="dlg" class="easyui-datagrid"
           style="width: auto; height: 500px;"
           url="<?php echo site_url('Member/getJson'); ?>"
           toolbar="#toolbar"
           footer="#footer"
           title="Data Member"
           fit="true"
           pagination="true"
           pageSize="10" pageList="[10, 20, 30, 50]"
           stripped="true" nowrap="false"
           fitColumns="true" singleSelect="true" remoteSort="false"
           rowNumbers="true">
      <thead>
        <tr>
          <th data-options="field: 'txtId', width: 50, sortable: true, hidden: true">ID Member</th>
          <th data-options="field: 'txtNamaMember', width: 100, sortable: true, align: 'left', halign: 'center'">Nama Member</th>
          <th data-options="field: 'txtAlamatMember', width: 100, sortable: true, align: 'left', halign: 'center'">Alamat Member</th>
          <th data-options="field: 'txtTempatLahirMember', width: 100, sortable: true, align: 'left', halign: 'center'">Tempat Lahir Member</th>
          <th data-options="field: 'txtTglLahirMember', width: 100, sortable: true, align: 'left', halign: 'center'">Tanggal Lahir Member</th>
          <th data-options="field: 'cmbJenkelMember', width: 100, sortable: true, align: 'left', halign: 'center'">Jenis Kelamin Member</th>
          <th data-options="field: 'txtNoKontakMember', width: 100, sortable: true, align: 'left', halign: 'center'">No Kontak Member</th>
          <th data-options="field: 'txtEmailMember', width: 100, sortable: true, align: 'left', halign: 'center'">Email Member</th>
        </tr>
      </thead>
    </table>

    <div id="form-dialog" class="easyui-dialog"
         style="width: 400px; padding: 12px;"
         buttons="#dlg-btn" closed="true">
      <form id="fm" action="index.html" method="post" novalidate>
        <table width="100%" class="form-table">
          <tr>
            <td>
              <input type="hidden" name="txtId" id="txtId">
            </td>
          </tr>
          <tr>
            <td>
              <label>Nama Member</label>
            </td>
            <td>
              <input type="text" name="txtNamaMember" id="txtNamaMember"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Alamat Member</label>
            </td>
            <td>
              <input type="text" name="txtAlamatMember" id="txtAlamatMember"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Tempat Lahir Member</label>
            </td>
            <td>
              <input type="text" name="txtTempatLahirMember" id="txtTempatLahirMember"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Tanggal Lahir Member</label>
            </td>
            <td>
              <input type="text" name="txtTglLahirMember" id="txtTglLahirMember"
                     class="easyui-datebox"
                     data-options="formatter: dateFormatter, parser: dateParser" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Jenis Kelamin Member</label>
            </td>
            <td>
              <select class="easyui-combobox" name="cmbJenkelMember" id="cmbJenkelMember"
                      data-options="prompt: '-- PILIH --', value: ''" required>
                <option value="P">Pria</option>
                <option value="W">Wanita</option>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label>No Kontak Member</label>
            </td>
            <td>
              <input type="text" name="txtNoKontakMember" id="txtNoKontakMember"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
          <tr>
            <td>
              <label>Email Member</label>
            </td>
            <td>
              <input type="text" name="txtEmailMember" id="txtEmailMember"
                     class="easyui-validatebox textbox"
                     maxlength="30" required>
            </td>
          </tr>
        </table>
      </form>
    </div>
    <div id="dlg-btn">
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-ok" onclick="saveData()">Simpan</a>
      <a href="javascript:void(0);" class="easyui-linkbutton"
         iconCls="icon-cancel" onclick="javascript:$('#form-dialog').dialog('close')">Batal</a>
    </div>

    <div id="search-dialog" class="easyui-dialog"
         style="width: 400px; height: auto; padding: 12px;"
         buttons="#src-btn" closed="true">
      <form id="sfm" action="index.html" method="post">
        <input type="text" class="easyui-searchbox"
               style="width: 100%;"
               data-options="prompt: 'Masukkan kata kunci pencarian', menu: '#mm', searcher: doSearch">

        <div id="mm">
          <div data-options="name: 'all', iconCls: 'icon-ok'">Semua</div>
          <div data-options="name: 'nama', iconCls: 'icon-ok'">Nama Member</div>
          <div data-options="name: 'alamat', iconCls: 'icon-ok'">Alamat Member</div>
          <div data-options="name: 'tempat_lahir', iconCls: 'icon-ok'">Tempat Lahir Member</div>
          <div data-options="name: 'tgl_lahir', iconCls: 'icon-ok'">Tanggal Lahir Member</div>
          <div data-options="name: 'jenkel', iconCls: 'icon-ok'">Jenis Kelamin Member</div>
          <div data-options="name: 'no_kontak', iconCls: 'icon-ok'">No Kontak Member</div>
          <div data-options="name: 'email', iconCls: 'icon-ok'">Email Member</div>
        </div>
      </form>
    </div>

    <script type="text/javascript">
      function saveData()
      {
        $('#fm').form('submit',
        {
          url:url,
          onSubmit: function()
          {
            return $(this).form('validate');
          },
          success: function(result)
          {
            var result = eval ('('+result+')');
            if(result.success)
            {
              $('#form-dialog').dialog('close');
              $('#dlg').datagrid('reload');
            } else
            {
              $.messager.show
              ({
                title: 'Error',
                msg: result.msg
              });
            }
          }
        });
      }

      function doSearch (value,name)
      {
        if (value !="")
        {
          $('#dlg').datagrid('load',{
            findId: name,
            findNilai: value
          });
        }
      }

      function dateFormatter(date) {
        var y = date.getFullYear();
        var m = date.getMonth()+1;
        var d = date.getDate();
        return y + '-' + (m<10?('0'+m):m) + '-' + (d<10?('0'+d):d);
      }

      function dateParser(s) {
        if (!s) return new Date();
        var ss = (s.split('-'));
        var y = parseInt(ss[0],10);
        var m = parseInt(ss[1],10);
        var d = parseInt(ss[2],10);
        if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
          return new Date(y, m-1, d);
        } else {
          return new Date();
        }
      }
    </script>
  </body>
</html>
